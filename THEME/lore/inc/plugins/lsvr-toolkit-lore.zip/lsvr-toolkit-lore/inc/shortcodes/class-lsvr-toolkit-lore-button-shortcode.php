<?php
/**
 * Button
 *
 * Simple button with a link
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Button_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Button_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_button', array(
                'title' => esc_html__( 'Button', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'Simple button with a link', 'lsvr-toolkit-lore' ),
                //'inline' => true,
                'atts' => array(
                    'label' => array(
                        'label' => esc_html__( 'Label', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Text of the button', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                        'default' => esc_html__( 'Click me', 'lsvr-toolkit-lore' ),
                    ),
                    'link' => array(
                        'label' => esc_html__( 'Link', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Add an absolute URL', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'size' => array(
                        'label' => esc_html__( 'Size', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Size of the button', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( 'small' => esc_html__( 'Small', 'lsvr-toolkit-lore' ), 'regular' => esc_html__( 'Regular', 'lsvr-toolkit-lore' ), 'large' => esc_html__( 'Large', 'lsvr-toolkit-lore' ) ),
                        'default' => 'regular',
                    ),
                    'style' => array(
                        'label' => esc_html__( 'Style', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Appearance of the button', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( 'default' => esc_html__( 'Default', 'lsvr-toolkit-lore' ), 'outline' => esc_html__( 'Outline', 'lsvr-toolkit-lore' ) ),
                        'default' => 'default',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'label' => '',
                    'link' => '',
                    'size' => 'regular',
                    'style' => 'default',
                    'custom_class' => '',
                ),
                $atts
            );

            $class_arr[] = $atts['custom_class'];
            $class_arr[] = 'm-size-' . $atts['size'];
            $class_arr[] = 'm-style-' . $atts['style'];
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <a class="c-button<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( $atts['link'] ); ?>"><?php echo strip_tags( $atts['label'], '<i><span>' ); ?></a>

            <?php return ob_get_clean();

        }

    }
}
?>