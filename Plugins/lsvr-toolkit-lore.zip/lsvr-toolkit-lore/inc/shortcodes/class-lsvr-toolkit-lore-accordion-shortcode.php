<?php
/**
 * Accordion
 *
 * Container for Accordion Item shortcodes
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Accordion_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
	class Lsvr_Toolkit_Lore_Accordion_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

			parent::__construct( 'lore_accordion', array(
				'title' => esc_html__( 'Accordion', 'lsvr-toolkit-lore' ),
				'description' => esc_html__( 'Container for Accordion Item shortcodes', 'lsvr-toolkit-lore' ),
                'paired' => true,
                'atts' => array(
                    'type' => array(
                        'label' => esc_html__( 'Type', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Choose between Default (only one expanded item at the time) or Toggle (multiple expanded items at the time) type', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array(
                            'default' => esc_html__( 'Default', 'lsvr-toolkit-lore' ),
                            'toggle' => esc_html__( 'Toggle', 'lsvr-toolkit-lore' ),
                        ),
                        'default' => 'default',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
			));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'type' => 'default',
                    'custom_class' => '',
                ),
                $atts
            );
            $class_arr[] = $atts['custom_class'];
            $class_arr[] = 'm-type-' . $atts['type'];
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <div class="c-accordion<?php echo esc_attr( $class ); ?>">
                <div class="accordion-inner">
                    <ul class="accordion-item-list">

                        <?php echo do_shortcode( $content ); ?>


                    </ul>
                </div>
            </div>

            <?php return ob_get_clean();

        }

	}
}
?>