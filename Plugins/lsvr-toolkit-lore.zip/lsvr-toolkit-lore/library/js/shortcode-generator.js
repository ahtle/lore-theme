/**
 * Shortcode Generator plugin
 */
(function($){ "use strict";
if ( ! $.fn.lsvrToolkitShortcodeGenerator ) {
	$.fn.lsvrToolkitShortcodeGenerator = function( shortcodesJSONparam, jsStrings ){

		var shortcodesJSON;
		try {
			shortcodesJSON = JSON.parse( JSON.stringify( shortcodesJSONparam ) );
		} catch(e) {
			shortcodesJSON = false;
			console.log( 'LSVR Toolkit Shortcodes JSON: INVALID JSON' );
		}

		if ( shortcodesJSON ) {

			var $openModalBtn = $(this),
				$modal = $( '.lsvr-sg-modal-overlay' ).length ? $( '.lsvr-sg-modal-overlay' ) : false,
				$modalOverlay = $( '.lsvr-sg-modal' ).length ? $( '.lsvr-sg-modal' ) : false,
				$shortcodeListSelect = $modal && $modal.find( '.lsvr-sg-shortcode-list' ).length ? $modal.find( '.lsvr-sg-shortcode-list' ) : false,
				$shortcodeForm = $modal && $modal.find( '.lsvr-sg-shortcode-form' ).length ? $modal.find( '.lsvr-sg-shortcode-form' ) : false,
				$addShortcodeBtn = $modal && $modal.find( '.lsvr-sg-add-shortcode' ).length ? $modal.find( '.lsvr-sg-add-shortcode' ) : false,
				$codePreviewHolder = $modal && $modal.find( '.lsvr-sg-code-preview-holder' ).length ? $modal.find( '.lsvr-sg-code-preview-holder' ) : false;

	    	/**
	    	 * Show modal
	    	 *
	    	 * Displays modal window with Shortcode Generator
	    	 */
			var showModal = function(){

				// Create modal if it doesn'te exists
				if ( ! $modal ) {
					createModal();
				}

				// Show modal
				updateShortcodeForm( $shortcodeListSelect.val() );
				refreshOverlay();

				$modal.fadeIn(300);
				$modalOverlay.fadeIn(300);

				$( 'body' ).addClass( 'lsvr-sg-locked-scrolling' );

			};

	    	/**
	    	 * Create modal
	    	 *
	    	 * Create modal window HTML
	    	 */
			var createModal = function(){

				var html = '<div class="lsvr-sg-modal-overlay"></div><div class="lsvr-sg-modal"><div class="lsvr-sg-modal-inner">';

				html += '<div class="lsvr-sg-modal-title"><strong>';
				html += 'undefined' !== typeof jsStrings.modal_title ? jsStrings.modal_title : 'Shortcode Generator';
				html += '</strong><span class="lsvr-sg-close dashicons dashicons-no-alt"></span></div>';
				html += '<div class="lsvr-sg-modal-content">';
				html += '<div class="lsvr-sg-modal-list-container"><label for="lsvr-sg-shortcode-list">';
				html += 'undefined' !== typeof jsStrings.choose_sc ? jsStrings.choose_sc : 'Choose shortcode from the list';
				html += '</label><select id="lsvr-sg-shortcode-list" class="lsvr-sg-shortcode-list lsvr-sg-selectbox">';

				// List shortcodes
				$.each( shortcodesJSON, function( key, value ) {
					html += '<option value="' + key + '">' + value.title + '</option>';
				});

				html += '</select></div><div class="lsvr-sg-shortcode-form"></div>';
				html += '<div class="lsvr-sg-footer">';
				html += '<p class="lsvr-sg-code-preview-holder"><label for="lsvr-sg-code-preview">';
				html += 'undefined' !== typeof jsStrings.code_preview_label ? jsStrings.code_preview_label : 'Shortcode Preview';
				html += '</label><textarea class="lsvr-sg-code-preview" id="lsvr-sg-code-preview"></textarea></p>';
				html += '<button type="button" class="lsvr-sg-add-shortcode button button-primary button-large">';
				html += 'undefined' !== typeof jsStrings.add_sc_btn ? jsStrings.add_sc_btn : 'Add Shortcode';
				html += '</button></div>';
				html += '</div></div></div>';

				// Insert modal HTML into page
				$( 'body' ).append( html );

				// Save important modal elements as variables
				$modal = $( '.lsvr-sg-modal' );
				$modalOverlay = $( '.lsvr-sg-modal-overlay' );
				$shortcodeListSelect = $modal.find( '.lsvr-sg-shortcode-list' );
				$shortcodeForm = $modal.find( '.lsvr-sg-shortcode-form' );
				$addShortcodeBtn = $modal.find( '.lsvr-sg-add-shortcode' );
				$codePreviewHolder = $modal.find( '.lsvr-sg-code-preview-holder' );

				// Set up preview shortcode textarea
				previewShortcodeCode();
				$codePreviewHolder.find( 'textarea' ).on( 'focus', function(){

					previewShortcodeCode();
					$(this).select();
					$(this).mouseup(function() {
						$(this).unbind( 'mouseup' );
						return false;
    				});

				});

				// Select shortcode from selectbox action
				$shortcodeListSelect.change( function(){

					// Update form with selected shortcode's fields
					updateShortcodeForm( $(this).val() );

					// Preview shortcode
					previewShortcodeCode();

				});

				// Add shortcode action
				$addShortcodeBtn.on( 'click', function(){

					// Send code to WP editor
					send_to_editor( createShortcodeCode() );
					hideModal();

					// Set cusror on the right position for paired shortcodes
					if ( 'undefined' !== typeof tinyMCE  ) {
						var lsvr_toolkit_sg_cursor_marker = tinyMCE.activeEditor.dom.select( '#lsvr-sg-cursor-marker' )[0];
						if ( 'undefined' !== typeof lsvr_toolkit_sg_cursor_marker ) {
							tinymce.activeEditor.selection.select( lsvr_toolkit_sg_cursor_marker );
							lsvr_toolkit_sg_cursor_marker.remove();
						}
					}

					return false;

				});

				// Hide modal when clicked on close button or outside of modal
				$( '.lsvr-sg-modal-overlay, .lsvr-sg-modal-title .lsvr-sg-close' ).click(function(){
					hideModal();
				});

			};

	    	/**
	    	 * Update shortcode form with options of selected shortcode
			 */
			var updateShortcodeForm = function( shortcode ){

				var shortcodeData = shortcodesJSON[shortcode],
					html = '';

				// Add shortcode description
				if ( shortcodeData.hasOwnProperty( 'description' ) ) {
					html += '<div class="lsvr-sg-shortcode-description"><p>' + shortcodeData.description + '</p></div>';
				}

				// Add attribute fields
				if ( shortcodeData.hasOwnProperty( 'atts' ) ) {
					$.each( shortcodeData.atts, function( index, value ) {

						// Text
						if ( 'text' === value.type ) {
							html += addTextinputField( index, value );
						}

						// Textarea
						else if ( 'textarea' === value.type ) {
							html += addTextareaField( index, value );
						}

						// Select
						else if ( 'select' === value.type ) {
							html += addSelectboxField( index, value );
						}

						// File
						else if ( 'file' === value.type ) {
							html += addFileinputField( index, value );
						}

						// Gallery
						else if ( 'gallery' === value.type ) {
							html += addGalleryField( index, value );
						}

					});
				}

				// Output form HTML
				$shortcodeForm.html( html );

				// Update textarea with generated code of current shortcode
				$shortcodeForm.find( 'input, select, textarea' ).on( 'change', function(){
					previewShortcodeCode();
				});

				/**
				 * Init file input field
				 *
				 * @link http://www.webmaster-source.com/2013/02/06/using-the-wordpress-3-5-media-uploader-in-your-plugin-or-theme/
				 */
				if ( 'undefined' !== typeof wp.media ) {

					var lsvrToolkitSgCustomUploader;

					$shortcodeForm.find( '.lsvr-sg-fileinput .lsvr-sg-btn' ).click(function(){

						var input = $(this).parent().find( '.lsvr-sg-att' );
						if ( lsvrToolkitSgCustomUploader ) {
							lsvrToolkitSgCustomUploader.open();
							return;
						}

						// Extend the wp.media object
						lsvrToolkitSgCustomUploader = wp.media.frames.file_frame = wp.media({
							multiple: false
						});

						// When a file is selected, grab the URL and set it as the text field's value
						lsvrToolkitSgCustomUploader.on( 'select', function() {
							var attachment = lsvrToolkitSgCustomUploader.state().get( 'selection' ).first().toJSON();
							input.val( attachment.url );
							previewShortcodeCode();
						});

						// Open the uploader dialog
						lsvrToolkitSgCustomUploader.open();

					});

				}
				else {
					$shortcodeForm.find( '.lsvr-sg-fileinput .lsvr-sg-btn' ).remove();
				}

				/**
				 * Init gallery field
				 *
				 * @link http://www.webmaster-source.com/2013/02/06/using-the-wordpress-3-5-media-uploader-in-your-plugin-or-theme/
				 */
				if ( 'undefined' !== typeof wp.media  ) {

					var lsvrSgCustomUploaderGallery;

					$shortcodeForm.find( '.lsvr-sg-gallery .lsvr-sg-btn' ).click(function(){

						var input = $(this).parent().find( '.lsvr-sg-att' ),
							preview = $(this).parent().find( '.lsvr-sg-gallery-preview' );

						if ( lsvrSgCustomUploaderGallery ) {
							lsvrSgCustomUploaderGallery.open();
							return;
						}

						// Extend the wp.media object
						lsvrSgCustomUploaderGallery = wp.media.frames.file_frame = wp.media({
							multiple: true
						});

						// When a file is selected, grab the URL and set it as the text field's value
						lsvrSgCustomUploaderGallery.on( 'select', function() {

							var id_arr = [],
								previewHtml = '',
								attachment = lsvrSgCustomUploaderGallery.state().get( 'selection' ).toJSON();

							// PARSE OBJECT
							if ( attachment.length > 0 ) {
								for ( var i = 0; i < attachment.length; i++ ) {
									id_arr.push( attachment[i].id );
									previewHtml += '<img src="' + attachment[i].sizes.thumbnail.url + '" alt="">';
								}
							}

							// Show images
							preview.html( previewHtml );
							preview.show();

							// Save IDs to input
							input.val( id_arr.join() );

							// Refresh code preview
							previewShortcodeCode();

						});

						// Open the uploader dialog
						lsvrSgCustomUploaderGallery.open();

					});

				}
				else {
					$shortcodeForm.find( '.lsvr-sg-gallery .lsvr-sg-btn' ).remove();
				}

			};

			/**
			 * Generate shortcode code
			 *
			 * Create final code with all attributes
			 */
			var createShortcodeCode = function(){

				var shortcodeData = shortcodesJSON[ $shortcodeListSelect.val() ],
					shortcodeCode = $shortcodeListSelect.val(),
					endtag = '';

				// Prepare end tag if shorcode is paired
				if ( true === shortcodeData.paired  ) {

					endtag = '<span id="lsvr-sg-cursor-marker">&nbsp;</span>';

					if ( true !== shortcodeData.inline  ) {
						endtag = '<p>' + endtag + '&nbsp;</p>';
					}
					endtag += '[/' + shortcodeCode + ']';

				}

				// Add attributes
				$shortcodeForm.find( '.lsvr-sg-att' ).each(function(){

					if ( '' !== $(this).val() ){
						shortcodeCode += ' ' + $(this).data( 'attname' ) + '="' + $(this).val() + '"';
					}

				});

				return '[' + shortcodeCode + ']' + endtag;

			};

			/**
			 * Preview shortcode code
			 *
			 * Paste generated code into textarea
			 */
			var previewShortcodeCode = function(){

				var placeholder = 'undefined' !== typeof jsStrings.code_preview_placeholder ? jsStrings.code_preview_placeholder : 'text';
				var shortcode = createShortcodeCode();
				shortcode = shortcode.replace( '<p><span id="lsvr-sg-cursor-marker">&nbsp;</span>&nbsp;</p>', '' );
				shortcode = shortcode.replace( '<span id="lsvr-sg-cursor-marker">&nbsp;</span>', '' );
				$codePreviewHolder.find( 'textarea' ).val( shortcode );
				if ( $codePreviewHolder.is( ':hidden' ) ) {
					$codePreviewHolder.show();
				}

			};

			/**
			 * Text field type
			 */
			var addTextinputField = function( name, atts ){

				var html = '<div class="lsvr-sg-form-row">';

				if ( 'undefined' !== typeof atts.label ) {
					html += '<label>' + atts.label + '</label>';
				}
				if ( 'undefined' !== typeof atts.description ) {
					html += '<p class="lsvr-sg-description">' + atts.description + '</p>';
				}

				html += '<input type="text" class="lsvr-sg-textinput lsvr-sg-att" data-attname="' + name + '"';
				if ( 'undefined' !== typeof atts.default ) {
					html += ' value="' + atts.default + '"';
				}
				html += '></div>';

				return html;

			};

			/**
			 * Textarea field type
			 */
			var addTextareaField = function( name, atts ){

				var html = '<div class="lsvr-sg-form-row">';

				if ( 'undefined' !== typeof atts.label ) {
					html += '<label>' + atts.label + '</label>';
				}
				if ( 'undefined' !== typeof atts.description ) {
					html += '<p class="lsvr-sg-description">' + atts.description + '</p>';
				}

				html += '<textarea class="lsvr-sg-textarea lsvr-sg-att" data-attname="' + name + '">';
				if ( 'undefined' !== typeof atts.default ) {
					html += atts.default;
				}
				html += '</textarea></div>';

				return html;

			};

			/**
			 * Selectbox field type
			 */
			var addSelectboxField = function( name, atts ){

				var html = '<div class="lsvr-sg-form-row">';

				if ( 'undefined' !== typeof atts.label ) {
					html += '<label>' + atts.label + '</label>';
				}
				if ( 'undefined' !== typeof atts.description ) {
					html += '<p class="lsvr-sg-description">' + atts.description + '</p>';
				}

				html += '<select class="lsvr-sg-selectbox lsvr-sg-att" data-attname="' + name + '">';
				$.each( atts.values, function( index, value ) {
					html += '<option value="' + index + '"';
					if ( 'undefined' !== typeof atts.default && index === atts.default ) {
						html += ' selected="selected"';
					}
					html += '>' + value + '</option>';
				});
				html += '</select></div>';

				return html;

			};

			/**
			 * File input field type
			 */
			var addFileinputField = function( name, atts ){

				var html = '<div class="lsvr-sg-form-row lsvr-sg-fileinput">';

				if ( 'undefined' !== typeof atts.label ) {
					html += '<label>' + atts.label + '</label>';
				}
				if ( 'undefined' !== typeof atts.description ) {
					html += '<p class="lsvr-sg-description">' + atts.description + '</p>';
				}

				html += '<input type="text" class="lsvr-sg-textinput lsvr-sg-att" data-attname="' + name + '">';
				html += '<div class="lsvr-sg-btn"><i class="dashicons dashicons-upload"></i></div>';
				html += '</div>';

				return html;

			};

			/**
			 * Gallery field type
			 */
			var addGalleryField = function( name, atts ){

				var html = '<div class="lsvr-sg-form-row lsvr-sg-gallery">';

				if ( 'undefined' !== typeof atts.label ) {
					html += '<label>' + atts.label + '</label>';
				}
				if ( 'undefined' !== typeof atts.description ) {
					html += '<p class="lsvr-sg-description">' + atts.description + '</p>';
				}

				html += '<p class="lsvr-sg-gallery-preview" style="display: none;"></p>';
				html += '<input type="hidden" class="lsvr-sg-textinput lsvr-sg-att" data-attname="' + name + '">';
				html += '<button type="button" class="lsvr-sg-btn button button-primary button-large">';
				html += 'undefined' !== typeof jsStrings.select_images_btn ? jsStrings.select_images_btn : 'Select Images';
				html += '</button></div>';

				return html;

			};

			/**
			 * Hide modal
			 */
			var hideModal = function(){
				$modalOverlay.fadeOut(300);
				$modal.fadeOut(300);
				$( 'body' ).removeClass( 'lsvr-sg-locked-scrolling' );
			};

			/**
			 * Refresh overlay
			 */
			var refreshOverlay = function(){
				$modalOverlay.css({
					'height' : $(document).height()
				});
			};
	    	$(window).resize(function(){
				refreshOverlay();
			});

			/**
			 * Open modal on click
			 */
			$openModalBtn.on( 'click', function(){
				showModal();
				return false;
			});

		}
		else {
			$(this).hide();
		}
	};
}
})(jQuery);