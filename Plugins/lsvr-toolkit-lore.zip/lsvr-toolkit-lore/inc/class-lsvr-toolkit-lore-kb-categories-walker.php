<?php
/**
 * Knowledge Base category list widget walker
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_KB_Categories_Walker' ) ) {
    class Lsvr_Toolkit_Lore_KB_Categories_Walker extends Walker_Category {

        function start_lvl( &$output, $depth = 1, $args = [] ) {
            $output .= '<ul class="children child-cats">';
        }

        function end_lvl( &$output, $depth = 0, $args = [] ) {
            $output .= '</ul>';
        }

        function start_el( &$output, $item, $depth = 0, $args = [], $id = 0 ) {

            $show_count = ! empty( $args['show_count'] ) ? true : false;
            $show_articles = ! empty( $args['show_articles'] ) ? true : false;
            $term_meta = get_option( 'taxonomy_' . $item->term_id );
            $current_cat = is_tax( 'lsvr_lore_kb_cat' ) && $item->term_id === get_queried_object()->term_id ? ' m-current-cat' : '';
            $category_icon = ! empty( $term_meta['category_icon_meta'] ) ? $term_meta['category_icon_meta'] : 'loreico loreico-folder';

            ob_start(); ?>

            <li class="cat-item<?php echo esc_attr( $current_cat ); ?>">
                <div class="item-link">
                    <div class="item-link-inner">
                        <i class="category-icon <?php echo esc_attr( $category_icon ); ?>"></i>
                        <a href="<?php echo esc_url( get_term_link( $item ) ); ?>"><?php echo esc_attr( $item->name ); ?></a>
                        <?php if ( true == $show_count ) : ?>
                            <span class="post-count">(<?php echo (int) $item->count; ?>)</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="children-holder m-level-<?php echo esc_attr( $depth ); ?>">

            <?php $output .= ob_get_clean();

        }

        function end_el( &$output, $item, $depth = 0, $args = [] ) {

            global $post;

            // Article list
            $show_articles = ! empty( $args['show_articles'] ) ? true : false;
            if ( true == $show_articles ) {

                // Query args
                $articles_args = array(
                    'post_type' => 'lsvr_lore_kb',
                    'numberposts' => 1000,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'lsvr_lore_kb_cat',
                            'field' => 'id',
                            'terms' => $item->term_id,
                            'include_children' => false,
                        ),
                    ),
                );

                // Query order
                if ( 'default' !== get_theme_mod( 'kb_articles_order', 'default' ) ) {
                    $orderby = get_theme_mod( 'kb_articles_order', 'default' );
                    $order = 'title' === $orderby || 'date_asc' === $orderby ? 'ASC' : 'DESC';
                    $orderby = 'date_asc' === $orderby || 'date_desc' === $orderby  ? 'date' : $orderby;
                    $articles_args['order'] = $order;
                    $articles_args['orderby'] = $orderby;
                }
                $articles = get_posts( $articles_args );

                ob_start(); ?>

                <?php if ( ! empty( $articles ) ) : ?>
                    <ul class="children child-posts">
                        <?php foreach ( $articles as $article ) : ?>

                            <?php $current_article = is_singular( 'lsvr_lore_kb' ) && $article->ID === $post->ID ? ' m-current-post' : ''; ?>

                            <li class="post-item<?php echo esc_attr( $current_article ); ?>">
                                <div class="item-link">
                                    <div class="item-link-inner">
                                        <?php if ( function_exists( 'lsvr_lore_the_kb_post_icon' ) ) {
                                            lsvr_lore_the_kb_post_icon( $article->ID, 'post-icon' );
                                        } ?>
                                        <a href="<?php echo esc_url( get_permalink( $article->ID ) ); ?>"><?php echo esc_html( $article->post_title ); ?></a>
                                    </div>
                                </div>
                            </li>

                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

                <?php $output .= ob_get_clean();

            }

            $output .= '</div></li>';

        }

    }
} ?>