<?php
/**
 * FAQ post type class
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_FAQ_CPT' ) && class_exists( 'Lsvr_Toolkit_Lore_CPT' ) ) {
    class Lsvr_Toolkit_Lore_FAQ_CPT extends Lsvr_Toolkit_Lore_CPT {

		public function __construct(){

			parent::__construct( 'lsvr_lore_faq', array(
				'labels' => array(
					'name' => esc_html__( 'FAQ', 'lsvr-toolkit-lore' ),
					'singular_name' => esc_html__( 'FAQ', 'lsvr-toolkit-lore' ),
					'add_new' => esc_html__( 'Add New FAQ', 'lsvr-toolkit-lore' ),
					'add_new_item' => esc_html__( 'Add New FAQ', 'lsvr-toolkit-lore' ),
					'edit_item' => esc_html__( 'Edit FAQ', 'lsvr-toolkit-lore' ),
					'new_item' => esc_html__( 'Add New FAQ', 'lsvr-toolkit-lore' ),
					'view_item' => esc_html__( 'View FAQ', 'lsvr-toolkit-lore' ),
					'search_items' => esc_html__( 'Search FAQ', 'lsvr-toolkit-lore' ),
					'not_found' => esc_html__( 'No FAQ found', 'lsvr-toolkit-lore' ),
					'not_found_in_trash' => esc_html__( 'No FAQ found in trash', 'lsvr-toolkit-lore' ),
				),
				'exclude_from_search' => false,
				'public' => true,
				'supports' => array( 'title', 'editor', 'custom-fields', 'revisions', 'excerpt' ),
				'capability_type' => 'post',
				'rewrite' => array( 'slug' => get_theme_mod( 'faq_slug', 'faq' ) ),
				'menu_position' => 5,
				'has_archive' => true,
				'show_in_nav_menus' => true,
				'menu_icon' => 'dashicons-lightbulb',
			));

			// Add FAQ Category taxonomy
			$this->add_taxonomy( 'lsvr_lore_faq_cat', array(
				'labels' => array(
					'name' => esc_html__( 'FAQ Categories', 'lsvr-toolkit-lore' ),
					'singular_name' => esc_html__( 'Category', 'lsvr-toolkit-lore' ),
					'search_items' => esc_html__( 'Search Categories', 'lsvr-toolkit-lore' ),
					'popular_items' => esc_html__( 'Popular Categories', 'lsvr-toolkit-lore' ),
					'all_items' => esc_html__( 'All Categories', 'lsvr-toolkit-lore' ),
					'parent_item' => esc_html__( 'Parent Category', 'lsvr-toolkit-lore' ),
					'parent_item_colon' => esc_html__( 'Parent Category:', 'lsvr-toolkit-lore' ),
					'edit_item' => esc_html__( 'Edit Category', 'lsvr-toolkit-lore' ),
					'update_item' => esc_html__( 'Update Category', 'lsvr-toolkit-lore' ),
					'add_new_item' => esc_html__( 'Add New Category', 'lsvr-toolkit-lore' ),
					'new_item_name' => esc_html__( 'New Category Name', 'lsvr-toolkit-lore' ),
					'separate_items_with_commas' => esc_html__( 'Separate categories with commas', 'lsvr-toolkit-lore' ),
					'add_or_remove_items' => esc_html__( 'Add or remove categories', 'lsvr-toolkit-lore' ),
					'choose_from_most_used' => esc_html__( 'Choose from the most used categories', 'lsvr-toolkit-lore' ),
					'menu_name' => esc_html__( 'Categories', 'lsvr-toolkit-lore' )
				),
				'public' => true,
				'show_in_nav_menus' => true,
				'show_ui' => true,
				'show_admin_column' => true,
				'show_tagcloud' => true,
				'hierarchical' => false,
				'rewrite' => array( 'slug' => get_theme_mod( 'faq_cat_slug', 'faq-category' ) ),
				'query_var' => true
			), true );

			// Add FAQ Tag taxonomy
			$this->add_taxonomy( 'lsvr_lore_faq_tag', array(
				'labels' => array(
					'name' => esc_html__( 'FAQ Tags', 'lsvr-toolkit-lore' ),
					'singular_name' => esc_html__( 'Tag', 'lsvr-toolkit-lore' ),
					'search_items' => esc_html__( 'Search tags', 'lsvr-toolkit-lore' ),
					'popular_items' => esc_html__( 'Popular Tags', 'lsvr-toolkit-lore' ),
					'all_items' => esc_html__( 'All Tags', 'lsvr-toolkit-lore' ),
					'parent_item' => esc_html__( 'Parent Tag', 'lsvr-toolkit-lore' ),
					'parent_item_colon' => esc_html__( 'Parent Tag:', 'lsvr-toolkit-lore' ),
					'edit_item' => esc_html__( 'Edit Tag', 'lsvr-toolkit-lore' ),
					'update_item' => esc_html__( 'Update Tag', 'lsvr-toolkit-lore' ),
					'add_new_item' => esc_html__( 'Add New Tag', 'lsvr-toolkit-lore' ),
					'new_item_name' => esc_html__( 'New Tag Name', 'lsvr-toolkit-lore' ),
					'separate_items_with_commas' => esc_html__( 'Separate tags with commas', 'lsvr-toolkit-lore' ),
					'add_or_remove_items' => esc_html__( 'Add or remove tags', 'lsvr-toolkit-lore' ),
					'choose_from_most_used' => esc_html__( 'Choose from the most used tags', 'lsvr-toolkit-lore' ),
					'menu_name' => esc_html__( 'Tags', 'lsvr-toolkit-lore' )
				),
				'public' => true,
				'show_in_nav_menus' => true,
				'show_ui' => true,
				'show_admin_column' => true,
				'show_tagcloud' => true,
				'hierarchical' => false,
				'rewrite' => array( 'slug' => get_theme_mod( 'faq_tag_slug', 'faq-tag' ) ),
				'query_var' => true
			), true );

		}

    }
}
?>