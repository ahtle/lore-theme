<?php
/**
 * Blog list
 *
 * Widgetized content area
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Blog_List_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Blog_List_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_blog_list', array(
                'title' => esc_html__( 'Blog List', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'Show latest blog posts', 'lsvr-toolkit-lore' ),
                'atts' => array(
                    'title' => array(
                        'label' => esc_html__( 'Title', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Leave blank to hide title', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                        'default' => esc_html__( 'Recent Blog Posts', 'lsvr-toolkit-lore' ),
                    ),
                    'limit' => array(
                        'label' => esc_html__( 'Post Count', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'How many posts to show. Set to 0 to show all posts', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( '0' => 0, '1' => 1, '2' => 2, '3' => 3, '4' => 4, '5' => 5, '6' => 6, '7' => 7, '8' => 8, '9' => 9, '10' => 10 ),
                        'default' => '3',
                    ),
                    'columns' => array(
                        'label' => esc_html__( 'Columns', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'How many columns to display', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( '1' => 1, '2' => 2, '3' => 3 ),
                        'default' => '3',
                    ),
                    'more_btn_label' => array(
                        'label' => esc_html__( 'More Button Label', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Link to blog posts archive. Leave blank to hide thi link', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                        'default' => esc_html__( 'More Posts', 'lsvr-toolkit-lore' ),
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'title' => '',
                    'limit' => '3',
                    'columns' => '3',
                    'more_btn_label' => '',
                    'custom_class' => '',
                ),
                $atts
            );

            $atts['limit'] = 0 === $atts['limit'] ? 1000 : $atts['limit'];

            $class_arr[] = $atts['custom_class'];
            $class_arr[] = 'm-' . esc_attr( $atts['columns'] ) . '-columns';
            $class = implode( ' ', array_filter( $class_arr ) ) !== '' ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <div class="c-blog-list<?php echo esc_attr( $class ); ?>">
                <div class="blog-list-inner">

                    <?php if ( ! empty( $atts['columns'] ) ) : ?>
                    <h2 class="blog-list-title"><?php echo get_theme_mod( 'defaultfp_blog_title', esc_html__( 'Recent Blog Posts', 'lore' ) ); ?></h2>
                    <?php endif; ?>

                    <?php $posts = get_posts(array(
                        'posts_per_page' => (int) $atts['limit'],
                    )); ?>
                    <?php if ( ! empty( $posts ) ) : ?>

                        <?php $col_class = floor( 12 / (int) $atts['columns'] ); ?>
                        <div class="blog-list-posts row">
                        <?php foreach ( $posts as $post ) : ?>
                            <div class="col-md-<?php echo esc_attr( $col_class ); ?>">
                                <div class="post-item">
                                    <?php if ( has_post_thumbnail( $post->ID ) ) : ?>
                                        <p class="post-thumbnail">
                                            <a href="<?php echo esc_url( get_permalink( $post->ID ) ); ?>"><?php echo get_the_post_thumbnail( $post->ID, 'large' ); ?></a>
                                        </p>
                                    <?php endif; ?>
                                    <p class="post-date"><?php echo get_the_date( get_option( 'date_format' ), $post->ID ); ?></p>
                                    <h3 class="post-title">
                                        <a href="<?php echo esc_url( get_permalink( $post->ID ) ); ?>"><?php echo get_the_title( $post->ID ); ?></a>
                                    </h3>
                                    <?php if ( ! empty( $post->post_excerpt ) ) : ?>
                                    <div class="post-excerpt">
                                        <?php if ( ! empty( $post->post_excerpt ) ) {
                                            echo wpautop( $post->post_excerpt );
                                        } elseif ( strpos( $post->post_content, '<!--more-->' ) ) {
                                            $post_excerpt = get_extended( $post->post_content );
                                            echo ! empty( $post_excerpt['main'] ) ? $post_excerpt['main'] : '';
                                        } ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        </div>

                    <?php else : ?>
                        <?php esc_html_e( 'There are currently no posts', 'lore' ); ?>
                    <?php endif; ?>

                    <?php if ( ! empty( $atts['more_btn_label'] ) ) : ?>
                    <p class="blog-list-more">
                        <span><a href="<?php echo esc_url( get_post_type_archive_link( 'post' ) ); ?>" class="c-button"><?php echo esc_html( $atts['more_btn_label'] ); ?></a></span>
                    </p>
                    <?php endif; ?>

                </div>
            </div>

            <?php return ob_get_clean();

        }

    }
}
?>