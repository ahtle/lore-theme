<?php
/**
 * FAQ posts
 *
 * Lists FAQ posts
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_FAQ_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
	class Lsvr_Toolkit_Lore_FAQ_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

			parent::__construct( 'lore_faq', array(
				'title' => esc_html__( 'FAQ List', 'lsvr-toolkit-lore' ),
				'description' => esc_html__( 'List FAQ posts. You can add FAQ posts under FAQ', 'lsvr-toolkit-lore' ),
                'atts' => array(
                    'title' => array(
                        'label' => esc_html__( 'Title', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                        'default' => esc_html__( 'FAQ', 'lsvr-toolkit-lore' ),
                    ),
                    'post_list' => array(
                        'label' => esc_html__( 'Specific FAQ Posts', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Display only specific FAQ posts. Insert IDs or slugs of those posts separated by comma. For example: "my-post-1,my-post-2" (without quotes). Category field will be ignored', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'limit' => array(
                        'label' => esc_html__( 'Number of FAQ Posts', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( '0' => esc_html__( 'All', 'lsvr-toolkit-lore' ), '1' => 1, '2' => 2, '3' => 3, '4' => 4, '5' => 5, '6' => 6, '7' => 7, '8' => 8, '9' => 9, '10' => 10 ),
                        'default' => '0',
                    ),
                    'default_state' => array(
                        'label' => esc_html__( 'Default State of Accordion', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array(
                            'closed' => esc_html__( 'Collapsed', 'lsvr-toolkit-lore' ),
                            'open' => esc_html__( 'Expanded', 'lsvr-toolkit-lore' ),
                        ),
                    ),
                    'enable_permalink' => array(
                        'label' => esc_html__( 'Show Permalink', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Show individual permalink or each FAQ post', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array(
                            'yes' => esc_html__( 'Enable', 'lsvr-toolkit-lore' ),
                            'no' => esc_html__( 'Disable', 'lsvr-toolkit-lore' ),
                        ),
                        'default' => 'no',
                    ),
                    'more_btn_label' => array(
                        'label' => esc_html__( 'More Button Label', 'lsvr-toolkit-lore' ),
						'description' => esc_html__( 'Link to FAQ posts archive. Leave blank to hide More button', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
			));

            // Add categories
            $categories_tax = get_categories( 'taxonomy=lsvr_lore_faq_cat&hide_empty=1&hierarchical=0&parent=0' ) ;
            if ( count( $categories_tax ) > 0 ) {
                $values = array( '0' => esc_html__( 'None', 'lsvr-toolkit-lore' ) );
                foreach ( $categories_tax as $value ) {
                    $values[ $value->cat_ID ] = $value->name;
                }
				$this->add_att(array(
					'name' => 'category',
					'atts' => array(
                		'label' => esc_html__( 'Category', 'lsvr-toolkit-lore' ),
                    	'description' => esc_html__( 'Category to load FAQ posts from. Choose "None" to load FAQ posts regardless of category', 'lsvr-toolkit-lore' ),
                    	'type' => 'select',
                    	'values' => $values,
                    	'default' => '0',
            		),
            		'add_as_first' => true,
				));
			}

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'category' => '0',
                    'title' => '',
                    'post_list' => '',
                    'limit' => '0',
                    'default_state' => 'closed',
                    'enable_permalink' => 'no',
                    'more_btn_label' => '',
                    'custom_class' => '',
                ),
                $atts
            );
            $atts['post_list'] = array_filter( explode( ',', str_replace( ', ', ',', esc_attr( $atts['post_list'] ) ) ) );
            $atts['category'] = (int) $atts['category'];
            $atts['limit'] = (int) $atts['limit'] < 1 ? 1000 : (int) $atts['limit'];
            $atts['enable_permalink'] = 'yes' === esc_attr( $atts['enable_permalink'] ) ? true : false;

            $class_arr[] = $atts['custom_class'];
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            // Query arguments
            $query_args = array(
                'posts_per_page' => (int) $atts['limit'],
                'post_type' => 'lsvr_lore_faq',
                'post_status' => array( 'publish' ),
            );

            // Post order
            if ( 'default' !== get_theme_mod( 'faq_order', 'default' ) ) {
                $orderby = get_theme_mod( 'faq_order', 'default' );
                $order = 'title' === $orderby || 'date_asc' === $orderby ? 'ASC' : 'DESC';
                $orderby = 'date_asc' === $orderby || 'date_desc' === $orderby ? 'date' : $orderby;
                $query_args['order'] = $order;
                $query_args['orderby'] = $orderby;
            }

            // Retrieve specific posts
            if ( ! empty( $atts['post_list'] ) ) {
                $post_list_ids = [];
                foreach ( $atts['post_list'] as $post_id ) {
                    if ( is_numeric( $post_id ) ) {
                        $post_list_ids[] = (int) $post_id;
                    } else {
                        $post_obj = get_page_by_path( $post_id, 'OBJECT', 'lsvr_lore_faq' );
                        if ( $post_obj ) {
                            $post_list_ids[] = (int) $post_obj->ID;
                        }
                    }
                }
                $query_args['post__in'] = $post_list_ids;
            }

            // Retrieve posts by category
            elseif ( ! empty( $atts['category'] ) ) {
                $query_args['tax_query'] = array(
                    array(
                        'taxonomy' => 'lsvr_lore_faq_cat',
                        'field' => 'id',
                        'terms' => array( (int) $atts['category'] ),
                    )
                );
            }

            // Query
            $posts = get_posts( $query_args );

            ob_start(); ?>

            <div class="c-faq-list<?php echo esc_attr( $class ); ?>">
                <div class="faq-inner">

                    <?php if ( '' !== $atts['title'] ) : ?>
                    <h2><span><?php echo esc_html( $atts['title'] ); ?></span></h2>
                    <?php endif; ?>

                    <?php if ( ! empty( $posts ) ) : ?>

                        <div class="faq-list-items">
                        <?php foreach ( $posts as $post ) : ?>
                            <article class="post-item<?php echo 'open' === $atts['default_state'] ? ' m-active' : ''; ?>">
                                <div class="post-item-inner">

                                    <header class="post-header">
                                        <h3 class="post-title"><?php echo esc_html( $post->post_title ); ?></h3>
                                    </header>

                                    <div class="post-content" itemprop="text"<?php if ( 'open' !== $atts['default_state'] ) { echo ' style="display: none;"'; } ?>>

                                        <?php if ( '' !== $post->post_excerpt ) {
                                            echo wpautop( $post->post_excerpt );
                                        } else {
                                            echo wpautop( $post->post_content );
                                        } ?>

                                        <?php if ( $atts['enable_permalink'] ) : ?>
                                        <p class="post-item-permalink">
                                            <a href="<?php echo esc_url( get_post_permalink( $post->ID ) ); ?>"><?php esc_html_e( 'Permalink', 'lsvr-toolkit-lore' ); ?></a>
                                        </p>
                                        <?php endif; ?>

                                    </div>

                                </div>
                            </article>
                        <?php endforeach; ?>
                        </div>

                        <?php if ( '' !== $atts['more_btn_label'] ) : ?>
                            <?php $more_btn_link = $atts['category'] > 0 ? get_term_link( (int) $atts['category'], 'lsvr_lore_faq_cat' ) : get_post_type_archive_link( 'lsvr_lore_faq' ); ?>
                            <p class="c-more-link"><a href="<?php echo esc_url( $more_btn_link ); ?>"><?php echo esc_html( $atts['more_btn_label'] ); ?></a></p>
                        <?php endif; ?>

                    <?php else : ?>
                        <?php echo wpautop( esc_html__( 'There are no FAQ at this time', 'lsvr-toolkit-lore' ) ); ?>
                    <?php endif; ?>

                </div>
            </div>

            <?php return ob_get_clean();

        }

	}
}
?>