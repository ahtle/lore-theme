<?php
/**
 * FAQ widget
 *
 * Display list of FAQ posts
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_FAQ_Widget' ) ) {
class Lsvr_Toolkit_Lore_FAQ_Widget extends WP_Widget {

	protected $defaults;

    public function __construct() {
        $widget_ops = array(
        	'classname' => 'lsvr-faq',
        	'description' => esc_html__( 'List FAQ', 'lsvr-toolkit-lore' ),
    	);
        parent::__construct( 'lsvr_lore_faq_widget', esc_html__( 'Lore FAQ Posts', 'lsvr-toolkit-lore' ), $widget_ops );
		$this->defaults = array(
			'title' => esc_html__( 'FAQ', 'lsvr-toolkit-lore' ),
			'category' => 0,
			'limit' => 5,
			'show_all_btn_label' => esc_html__( 'See All FAQ', 'lsvr-toolkit-lore' ),
		);
    }

    function form( $instance ) {

        $instance = wp_parse_args( (array) $instance, $this->defaults );
        $instance['category'] = (int) $instance['category'];
        $instance['limit'] = (int) $instance['limit'];

        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'lsvr-toolkit-lore' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>

		<?php $terms_arr = get_terms( 'lsvr_lore_faq_cat' ); ?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>"><?php echo esc_html__( 'Category:', 'lsvr-toolkit-lore' ); ?></label>
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'category' ) ); ?>">
			<option value="0"<?php if ( 0 === $instance['category'] ) { echo ' selected'; } ?>><?php esc_html_e( 'None', 'lsvr-toolkit-lore' ); ?></option>
			<?php if ( is_array( $terms_arr ) ) : ?>
				<?php foreach ( $terms_arr as $term ) : ?>
					<?php if ( is_object( $term ) && property_exists( $term, 'term_id' ) && property_exists( $term, 'name' ) ) : ?>
						<option value="<?php echo esc_attr( $term->term_id ); ?>"<?php if ( ( $instance['category'] > 0 ) && ( $instance['category'] === $term->term_id ) ) { echo ' selected'; } ?>><?php echo esc_html( $term->name ); ?></option>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php endif; ?>
		</select></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>"><?php echo esc_html__( 'Limit:', 'lsvr-toolkit-lore' ); ?></label>
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>">
			<option value="0"<?php if ( $instance['limit'] === 0 ) { echo ' selected'; } ?>><?php esc_html_e( 'None (list all)', 'lsvr-toolkit-lore' ); ?></option>
			<?php for ( $i = 1; $i <= 10; $i++ ) : ?>
				<option value="<?php echo esc_attr( $i ); ?>"<?php if ( $instance['limit'] === $i ) { echo ' selected'; } ?>><?php echo esc_attr( $i ); ?></option>
			<?php endfor; ?>
		</select></p>

		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_all_btn_label' ) ); ?>"><?php echo esc_html__( 'More Button Label:', 'lsvr-toolkit-lore' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'show_all_btn_label' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_all_btn_label' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['show_all_btn_label'] ); ?>">
        </p>
		<p><?php esc_html_e( 'Leave blank to disable more button.', 'lsvr-toolkit-lore' ); ?></p>

        <?php

    }

    function update( $new_instance, $old_instance ) {

        $instance = $old_instance;

        $instance['title'] = $new_instance['title'];
		$instance['category'] = $new_instance['category'];
		$instance['limit'] = $new_instance['limit'];
		$instance['show_all_btn_label'] = $new_instance['show_all_btn_label'];
        return $instance;

    }

    function widget( $args, $instance ) {

		$instance = empty( $instance ) ? wp_parse_args( (array) $instance, $this->defaults ) : $instance;
        $instance['title'] = apply_filters( 'widget_title', $instance['title'] );
		$instance['category'] = (int) $instance['category'];
        $instance['limit'] = 0 === (int) $instance['limit'] ? 1000 : (int) $instance['limit'];

        ?>

		<?php echo $args['before_widget']; ?>
        <?php if ( '' !== $instance['title'] ) { echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; } ?>
        <div class="widget-content">

			<?php // Query args
			$query_args = array(
				'posts_per_page' => (int) $instance['limit'],
				'post_type' => 'lsvr_lore_faq',
				'post_status' => array( 'publish' ),
				'suppress_filters' => true,
			);

			// Order
			if ( 'default' !== get_theme_mod( 'faq_order', 'default' ) ) {
				$orderby = get_theme_mod( 'faq_order', 'default' );
				$order = 'title' === $orderby  || 'date_asc' === $orderby ? 'ASC' : 'DESC';
				$orderby = 'date_asc' === $orderby || 'date_desc' === $orderby ? 'date' : $orderby;
				$query_args['order'] = $order;
				$query_args['orderby'] = $orderby;
			}

			// Category
			if ( $instance['category'] > 0 ) {
				$query_args['tax_query'] = array(
					array(
						'taxonomy' => 'lsvr_lore_faq_cat',
						'field' => 'id',
						'terms' => array( (int) $instance['category'] ),
					),
				);
			}

			// Get posts
			$posts = get_posts( $query_args ); ?>

			<?php if ( is_singular( 'lsvr_lore_faq' ) ) {
				global $wp_query;
				$current_id = $wp_query->queried_object;
				$current_id = $current_id->ID;
			} else {
				$current_id = false;
			} ?>

			<?php if ( ! empty( $posts ) ) : ?>

				<ul>
				<?php foreach ( $posts as $post ) : ?>
					<li<?php if ( $current_id && $current_id === $post->ID ) { echo ' class="m-current"'; } ?>><a href="<?php echo esc_url( get_post_permalink( $post->ID ) ); ?>"><?php echo esc_html( $post->post_title ); ?></a></li>
				<?php endforeach; ?>
				</ul>

				<?php if ( '' !== $instance['show_all_btn_label'] ) : ?>
					<?php $instance['show_all_btn_link'] = $instance['category'] > 0 ? get_term_link( (int) $instance['category'], 'lsvr_lore_faq_cat' ) : get_post_type_archive_link( 'lsvr_lore_faq' ); ?>
					<p class="widget-more-link">
						<a href="<?php echo esc_url( $instance['show_all_btn_link'] ); ?>"><?php echo esc_html( $instance['show_all_btn_label'] ); ?></a>
					</p>
				<?php endif; ?>

			<?php else : ?>
				<p><?php esc_html_e( 'There are currently no FAQ posts', 'lsvr-toolkit-lore' ); ?></p>
			<?php endif; ?>

        </div>
		<?php echo $args['after_widget']; ?>

        <?php

    }

}}

?>