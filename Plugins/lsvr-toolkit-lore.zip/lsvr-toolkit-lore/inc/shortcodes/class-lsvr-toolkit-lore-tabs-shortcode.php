<?php
/**
 * Tabs
 *
 * Container for Tab Item shortcodes
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Tabs_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
	class Lsvr_Toolkit_Lore_Tabs_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

			parent::__construct( 'lore_tabs', array(
				'title' => esc_html__( 'Tabs', 'lsvr-toolkit-lore' ),
				'description' => esc_html__( 'Container for Tab Item shortcodes', 'lsvr-toolkit-lore' ),
                'paired' => true,
                'atts' => array(
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
			));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'custom_class' => '',
                ),
                $atts
            );
            $class_arr[] = $atts['custom_class'];
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            $tab_content_list = do_shortcode( $content );

            ob_start(); ?>

            <div class="c-tabs<?php echo esc_attr( $class ); ?>">
                <div class="tabs-inner">

                    <ul class="tabs-title-list">
                        <?php $index = 0; ?>
                        <?php foreach ( parent::$tabs_title_arr as $tab_title ) : ?>
                            <li class="tab-title<?php echo (int) $index === 0 ? ' m-active' : ''; ?>"><?php echo strip_tags( $tab_title, '<span><i>' ); ?></li>
                            <?php $index += 1; ?>
                        <?php endforeach; ?>
                        <?php parent::$tabs_title_arr = []; ?>
                    </ul>

                    <ul class="tabs-content-list">
                        <?php echo $tab_content_list; ?>
                    </ul>

                </div>
            </div>

            <?php return ob_get_clean();

        }

	}
}
?>