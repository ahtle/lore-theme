<?php
/**
 * Alert message
 *
 * Container with a text
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Alert_Message_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Alert_Message_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_alert_message', array(
                'title' => esc_html__( 'Alert Message', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'Text message', 'lsvr-toolkit-lore' ),
                'paired' => true,
                'atts' => array(
                    'type' => array(
                        'label' => esc_html__( 'Type', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Message type', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( 'info' => esc_html__( 'Info', 'lsvr-toolkit-lore' ), 'warning' => esc_html__( 'Warning', 'lsvr-toolkit-lore' ), 'success' => esc_html__( 'Success', 'lsvr-toolkit-lore' ) ),
                        'default' => 'info',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'text' => '',
                    'type' => 'info',
                    'custom_class' => '',
                ),
                $atts
            );

            $class_arr[] = $atts['custom_class'];
            $class_arr[] = 'm-type-' . $atts['type'];
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <div class="c-alert-message<?php echo esc_attr( $class ); ?>"><?php echo wpautop( $content ); ?></div>

            <?php return ob_get_clean();

        }

    }
}
?>