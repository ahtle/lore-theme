<?php
/**
 * Row Column
 *
 * Should be nested inside Row shortcode to create multiple columns
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Row_Column_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Row_Column_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_row_column', array(
                'title' => esc_html__( 'Row Column', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'Should be nested inside Row shortcode', 'lsvr-toolkit-lore' ),
                'paired' => true,
                'atts' => array(
                    'size' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Size of the column', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( '1' => 1, '2' => 2, '3' => 3, '4' => 4, '5' => 5, '6' => 6, '7' => 7, '8' => 8, '9' => 9, '10' => 10, '11' => 11, '12' => 12 ),
                        'default' => '6',
                    ),
                    'offset' => array(
                        'label' => esc_html__( 'Offset', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Left margin of this column', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( '0' => 0, '1' => 1, '2' => 2, '3' => 3, '4' => 4, '5' => 5, '6' => 6, '7' => 7, '8' => 8, '9' => 9, '10' => 10, '11' => 11 ),
                        'default' => '0',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'size' => '6',
                    'offset' => '0',
                    'custom_class' => '',
                ),
                $atts
            );

            $class_arr[] = $atts['custom_class'];
            $class_arr[] = ! empty( $atts['offset'] ) ? 'col-md-offset-' . $atts['offset'] : '';
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <div class="col-md-<?php echo (int) esc_attr( $atts['size'] ); ?> <?php echo esc_attr( $class ); ?>">
                <?php echo do_shortcode( $content ); ?>
            </div>

            <?php return ob_get_clean();

        }

    }
}
?>