<?php
/**
 * Accordion Item
 *
 * It have to be nested in Accordion shortcode
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Accordion_Item_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
	class Lsvr_Toolkit_Lore_Accordion_Item_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

			parent::__construct( 'lore_accordion_item', array(
				'title' => esc_html__( 'Accordion Item', 'lsvr-toolkit-lore' ),
				'description' => esc_html__( 'It have to be nested in Accordion shortcode', 'lsvr-toolkit-lore' ),
                'paired' => true,
                'atts' => array(
                    'title' => array(
                        'label' => esc_html__( 'Title', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Title of this accordion item', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'state' => array(
                        'label' => esc_html__( 'State', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Choose the default state of this accordion item', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array(
                            'closed' => esc_html__( 'Closed', 'lsvr-toolkit-lore' ),
                            'open' => esc_html__( 'Open', 'lsvr-toolkit-lore' ),
                        ),
                        'default' => 'closed',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
			));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'title' => '',
                    'state' => 'default',
                    'custom_class' => '',
                ),
                $atts
            );
            $class_arr[] = $atts['custom_class'];
            $class_arr[] = $atts['state'] === 'open' ? 'm-active' : '';
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <li class="accordion-item<?php echo esc_attr( $class ); ?>">
                <div class="accordion-item-inner">

                    <h3 class="accordion-item-title"><?php echo strip_tags( $atts['title'], '<i><span>' ); ?></h3>

                    <div class="accordion-item-content"<?php echo esc_attr( $atts['state'] ) !== 'open' ? ' style="display: none;"' : ''; ?>>
                        <?php echo do_shortcode( $content ); ?>
                    </div>

                </div>
            </li>

            <?php return ob_get_clean();

        }

	}
}
?>