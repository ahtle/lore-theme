<?php
/**
 * Plugin Name: Lore Theme Toolkit
 * Description: Adds theme-specific functionality
 * Version: 1.0.2
 * Author: LSVRthemes
 * Author URI: http://themeforest.net/user/LSVRthemes/portfolio
 * License: GPLv2
 * Text Domain: lsvr-toolkit-lore
 * Domain Path: /languages
*/

/**
 * Load textdomain
 */
add_action( 'plugins_loaded', 'lsvr_toolkit_lore_load_textdomain' );
if ( ! function_exists( 'lsvr_toolkit_lore_load_textdomain' ) ) {
	function lsvr_toolkit_lore_load_textdomain() {
		load_plugin_textdomain( 'lsvr-toolkit-lore', false, plugin_basename( dirname( __FILE__ ) ) . '/languages/' );
	}
}

/**
 * Load admin CSS & JS
 */
add_action( 'admin_enqueue_scripts', 'lsvr_toolkit_lore_load_scripts' );
if ( ! function_exists( 'lsvr_toolkit_lore_load_scripts' ) ) {
	function lsvr_toolkit_lore_load_scripts() {
    	wp_enqueue_script( 'lsvr-toolkit-lore-scripts', plugin_dir_url( __FILE__ ) . '/library/js/scripts.js', array( 'jquery' ) );
    	wp_enqueue_style( 'lsvr-toolkit-lore-sg-styles', plugin_dir_url( __FILE__ ) . '/library/css/shortcode-generator.css', false );
    	wp_enqueue_script( 'lsvr-toolkit-lore-sg-scripts', plugin_dir_url( __FILE__ ) . '/library/js/shortcode-generator.js', array( 'jquery' ) );
	}
}

/**
 * Include additional functions and classes
 */
require_once( 'inc/class-lsvr-toolkit-lore-cpt.php' );
require_once( 'inc/class-lsvr-toolkit-lore-shortcode.php' );
require_once( 'inc/class-lsvr-toolkit-lore-shortcode-generator.php' );
require_once( 'inc/class-lsvr-toolkit-lore-kb-categories-walker.php' );

/**
 * Register FAQ post type
 */
require_once( 'inc/cpt/class-lsvr-toolkit-lore-faq-cpt.php' );
if ( class_exists( 'Lsvr_Toolkit_Lore_FAQ_CPT' ) ) {
	$lsvr_toolkit_lore_FAQ_CPT = new Lsvr_Toolkit_Lore_FAQ_CPT();
}

/**
 * Register Knowledge Base post type
 */
require_once( 'inc/cpt/class-lsvr-toolkit-lore-kb-cpt.php' );
if ( class_exists( 'Lsvr_Toolkit_Lore_KB_CPT' ) ) {
	$lsvr_toolkit_lore_KB_CPT = new Lsvr_Toolkit_Lore_KB_CPT();
}

/**
 * Register widgets
 */
add_action( 'widgets_init', 'lsvr_toolkit_lore_register_widgets' );
if ( ! function_exists( 'lsvr_toolkit_lore_register_widgets' ) ) {
	function lsvr_toolkit_lore_register_widgets() {

		$path_prefix = 'inc/widgets/';

		// FAQ
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-faq-widget.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_FAQ_Widget' ) ) {
			register_widget( 'Lsvr_Toolkit_Lore_FAQ_Widget' );
		}

		// FAQ categories
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-faq-categories-widget.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_FAQ_Categories_Widget' ) ) {
			register_widget( 'Lsvr_Toolkit_Lore_FAQ_Categories_Widget' );
		}

		// Knowledge Base categories
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-kb-categories-widget.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_KB_Categories_Widget' ) ) {
			register_widget( 'Lsvr_Toolkit_Lore_KB_Categories_Widget' );
		}

		// Knowledge Base articles
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-kb-articles-widget.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_KB_Articles_Widget' ) ) {
			register_widget( 'Lsvr_Toolkit_Lore_KB_Articles_Widget' );
		}

	}
}

/**
 * Register shortcodes
 */
add_action( 'init', 'lsvr_toolkit_lore_register_shortcodes' );
if ( ! function_exists( 'lsvr_toolkit_lore_register_shortcodes' ) ) {
	function lsvr_toolkit_lore_register_shortcodes() {

		$path_prefix = 'inc/shortcodes/';

    	// Accordion
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-accordion-shortcode.php' );
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-accordion-item-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Accordion_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Accordion_Item_Shortcode' ) ) {
			add_shortcode( 'lore_accordion', array( 'Lsvr_Toolkit_Lore_Accordion_Shortcode', 'shortcode' ) );
			add_shortcode( 'lore_accordion_item', array( 'Lsvr_Toolkit_Lore_Accordion_Item_Shortcode', 'shortcode' ) );
		}

    	// Alert message
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-alert-message-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Alert_Message_Shortcode' ) ) {
			add_shortcode( 'lore_alert_message', array( 'Lsvr_Toolkit_Lore_Alert_Message_Shortcode', 'shortcode' ) );
		}

    	// Blog list
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-blog-list-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Blog_List_Shortcode' ) ) {
			add_shortcode( 'lore_blog_list', array( 'Lsvr_Toolkit_Lore_Blog_List_Shortcode', 'shortcode' ) );
		}

    	// Button
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-button-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Button_Shortcode' ) ) {
			add_shortcode( 'lore_button', array( 'Lsvr_Toolkit_Lore_Button_Shortcode', 'shortcode' ) );
		}

    	// Table of contents
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-contents-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Contents_Shortcode' ) ) {
			add_shortcode( 'lore_contents', array( 'Lsvr_Toolkit_Lore_Contents_Shortcode', 'shortcode' ) );
		}

    	// Content grid
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-content-grid-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Content_Grid_Shortcode' ) ) {
			add_shortcode( 'lore_content_grid', array( 'Lsvr_Toolkit_Lore_Content_Grid_Shortcode', 'shortcode' ) );
		}

    	// Feature
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-feature-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Feature_Shortcode' ) ) {
			add_shortcode( 'lore_feature', array( 'Lsvr_Toolkit_Lore_Feature_Shortcode', 'shortcode' ) );
		}

    	// Google Map
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-gmap-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Gmap_Shortcode' ) ) {
			add_shortcode( 'lore_gmap', array( 'Lsvr_Toolkit_Lore_Gmap_Shortcode', 'shortcode' ) );
		}

    	// List of Knowledge Base articles
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-kb-articles-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_KB_Articles_Shortcode' ) ) {
			add_shortcode( 'lore_kb_articles', array( 'Lsvr_Toolkit_Lore_KB_Articles_Shortcode', 'shortcode' ) );
		}

    	// List of FAQ posts
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-faq-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_FAQ_Shortcode' ) ) {
			add_shortcode( 'lore_faq', array( 'Lsvr_Toolkit_Lore_FAQ_Shortcode', 'shortcode' ) );
		}

    	// Row
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-row-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Row_Shortcode' ) ) {
			add_shortcode( 'lore_row', array( 'Lsvr_Toolkit_Lore_Row_Shortcode', 'shortcode' ) );
		}

    	// Row Column
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-row-column-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Row_Column_Shortcode' ) ) {
			add_shortcode( 'lore_row_column', array( 'Lsvr_Toolkit_Lore_Row_Column_Shortcode', 'shortcode' ) );
		}

    	// Separator
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-separator-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Separator_Shortcode' ) ) {
			add_shortcode( 'lore_separator', array( 'Lsvr_Toolkit_Lore_Separator_Shortcode', 'shortcode' ) );
		}

    	// Tabs
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-tabs-shortcode.php' );
		require_once( $path_prefix . 'class-lsvr-toolkit-lore-tab-item-shortcode.php' );
		if ( class_exists( 'Lsvr_Toolkit_Lore_Tabs_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Tab_Item_Shortcode' ) ) {
			add_shortcode( 'lore_tabs', array( 'Lsvr_Toolkit_Lore_Tabs_Shortcode', 'shortcode' ) );
			add_shortcode( 'lore_tab_item', array( 'Lsvr_Toolkit_Lore_Tab_Item_Shortcode', 'shortcode' ) );
		}

	}
}

/**
 * Init Shortcode Generator
 *
 * SG should be initialized only on post edit admin screens
 */
if ( is_admin() && ( strstr( $_SERVER['REQUEST_URI'], 'wp-admin/post-new.php' ) || strstr( $_SERVER['REQUEST_URI'], 'wp-admin/post.php' ) ) &&
		class_exists( 'Lsvr_Toolkit_Lore_Shortcode_Generator' ) ) {
	add_action( 'init', 'lsvr_toolkit_lore_init_shortcode_generator' );
	if ( ! function_exists( 'lsvr_toolkit_lore_init_shortcode_generator' ) ) {
		function lsvr_toolkit_lore_init_shortcode_generator() {
			$lsvr_toolkit_lore_shortcode_generator = new Lsvr_Toolkit_Lore_Shortcode_Generator(array(
				'prefix' => 'lsvr_toolkit_lore',
				'js_strings' => array(
		            'modal_title' => esc_html__( 'Shortcode Generator', 'lsvr-toolkit-lore' ),
		            'choose_sc' => esc_html__( 'Choose shortcode from the list:', 'lsvr-toolkit-lore' ),
		            'select_images_btn' => esc_html__( 'Select Images', 'lsvr-toolkit-lore' ),
		            'code_preview_label' => esc_html__( 'Shortcode Preview', 'lsvr-toolkit-lore' ),
		            'code_preview_placeholder' => esc_html__( 'add your content here', 'lsvr-toolkit-lore' ),
		            'add_sc_btn' => esc_html__( 'Add Shortcode', 'lsvr-toolkit-lore' ),
				),
				'add_sg_button_label' => esc_html__( 'Add Shortcode', 'lsvr-toolkit-lore' ),
			));
		}
	}
}

/**
 * Sanitize Shortcodes
 *
 * Remove redudant P and BR tags from theme's shortcodes
 */
add_filter( 'the_content', 'lsvr_toolkit_lore_sanitize_shortcodes' );
if ( ! function_exists( 'lsvr_toolkit_lore_sanitize_shortcodes' ) ) {
	function lsvr_toolkit_lore_sanitize_shortcodes( $content ) {

        global $shortcode_tags;

		// Create array of custom shortcodes which are not inline
        if ( ! empty( $shortcode_tags ) ) {
            $shortcode_list = [];
            foreach ( $shortcode_tags as $shortcode_name => $shortcode_arr ){
                if ( 'lore_' === strtolower( substr( $shortcode_name, 0, 5 ) ) && is_array( $shortcode_arr ) &&
                		is_string( $shortcode_arr[0] ) && class_exists( $shortcode_arr[0] ) ) {
                    $shortcode_obj = new $shortcode_arr[0];
                    if ( ! $shortcode_obj->is_inline() ) {
                        $shortcode_list[] = $shortcode_name;
                    }
                }
            }
        }

		// Push some 3rd party shortcodes
        $shortcode_list = array_merge( $shortcode_list, array( 'contact-form-7', 'response' ), apply_filters( 'lsvr_toolkit_lore_sanitized_shortcodes', [] ) );
        $block = join( '|', $shortcode_list );

    	// Sanitize
    	$rep = preg_replace( "/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]", $content );
    	$rep = preg_replace( "/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]", $rep );

    	return $rep;

	}
}

/**
 * Get array with image data
 */
if ( ! function_exists( 'lsvr_toolkit_lore_get_image_data' ) ) {
    function lsvr_toolkit_lore_get_image_data( $image_id ){

        $image_data = [];
        $image_sizes = array( 'thumbnail', 'medium', 'large', 'full' );

        foreach ( $image_sizes as $size ) {
            $temp = wp_get_attachment_image_src( $image_id, $size );
            $image_data[$size] = $temp[0];
        }

		// Get alt
        $image_data['alt'] = get_post_meta( $image_id, '_wp_attachment_image_alt', true );

		// Get title
        $image_meta = wp_get_attachment_metadata( $image_id );
        if ( ! empty( $image_meta['title'] ) ){
            $image_data['title'] = $image_meta['title'];
        }
        else {
            $image_data['title'] = '';
        }

		// Get caption
		$image_post_data = get_post( $image_id );
		if ( $image_post_data && is_object( $image_post_data ) ) {
			$image_data['caption'] = $image_post_data->post_excerpt;
		}
		else {
			$image_data['caption'] = '';
		}

        if ( ! empty( $image_data ) ) {
            return $image_data;
        }
        else {
            return false;
        }

    }
}

?>