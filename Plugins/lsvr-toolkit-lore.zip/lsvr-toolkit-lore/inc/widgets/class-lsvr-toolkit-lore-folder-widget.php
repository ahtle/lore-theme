<?php
/**
 * Feature widget
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Folder_Widget' ) ) {
class Lsvr_Toolkit_Lore_Folder_Widget extends WP_Widget {

    protected $defaults;

    public function __construct() {
        $widget_ops = array(
            'classname' => 'lsvr-folder',
            'description' => esc_html__( 'Box with icon, title, text and links', 'lsvr-toolkit-lore' ),
        );
        parent::__construct( 'lsvr_lore_folder', esc_html__( 'Lore Folder', 'lsvr-toolkit-lore' ), $widget_ops );
        $this->defaults = array(
            'title' => '',
            'title_link' => '',
            'icon' => '',
            'text' => '',
            'links' => '',
        );
    }

    function form( $instance ) {

        $instance = wp_parse_args( (array) $instance, $this->defaults );

        ?>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'lsvr-toolkit-lore' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title_link' ) ); ?>"><?php echo esc_html__( 'Title Link:', 'lsvr-toolkit-lore' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title_link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title_link' ) ); ?>" type="text" value="<?php echo esc_url( $instance['title_link'] ); ?>">
        </p>
        <p class="description"><?php esc_html_e( 'Leave blank to do not link the title', 'lsvr-toolkit-lore' ); ?></p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'icon' ) ); ?>"><?php echo esc_html__( 'Icon:', 'lsvr-toolkit-lore' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'icon' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icon' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['icon'] ); ?>">
        </p>
        <p class="description"><?php esc_html_e( 'Icon which will be displayed above title. Insert name of the icon (e.g. "loreico loreico-heart"). Please refer to the documentation to learn more about using the icons', 'lsvr-toolkit-lore' ); ?></p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>"><?php echo esc_html__( 'Text:', 'lsvrtoolkit' ); ?></label>
            <textarea rows="6" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text' ) ); ?>"><?php echo esc_textarea( $instance['text'] ); ?></textarea>
        </p>
        <p class="description"><?php esc_html_e( 'Basic text which will be displayed under title', 'lsvr-toolkit-lore' ); ?></p>

        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'links' ) ); ?>"><?php echo esc_html__( 'Links:', 'lsvrtoolkit' ); ?></label>
            <textarea rows="6" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'links' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'links' ) ); ?>"><?php echo esc_textarea( $instance['links'] ); ?></textarea>
        </p>
        <p class="description"><?php echo esc_html__( 'Links with their respective labels. Add each label and its link on a separate line. For example:', 'lsvr-toolkit-lore' ) . '<br>' . esc_html__( 'Label 1', 'lsvr-toolkit-lore' ) . '<br>' . esc_html__( 'http://example.com/link1' ,'lsvr-toolkit-lore' ) . '<br>' . esc_html__( 'Label 2', 'lsvr-toolkit-lore' ) . '<br>' . esc_html__( 'http://example.com/link2', 'lsvr-toolkit-lore' ); ?></p>

        <?php

    }

    function update( $new_instance, $old_instance ) {

        $instance = $old_instance;

        $instance['title'] = $new_instance['title'];
        $instance['title_link'] = $new_instance['title_link'];
        $instance['icon'] = $new_instance['icon'];
		$instance['text'] = $new_instance['text'];
		$instance['links'] = $new_instance['links'];

        return $instance;

    }

    function widget( $args, $instance ) {

        $instance = empty( $instance ) ? wp_parse_args( (array) $instance, $this->defaults ) : $instance;
        $instance['title'] = apply_filters( 'widget_title', $instance['title'] );
        $instance['links'] = '' !== $instance['links'] ? array_chunk( preg_split( '/\r\n|[\r\n]/', $instance['links'] ), 2 ) : '';

        ?>

		<?php echo $args['before_widget']; ?>
        <div class="widget-content">

        	<?php if ( '' !== $instance['icon'] ) : ?>
        	<div class="folder-icon"><i class="<?php echo esc_attr( $instance['icon'] ); ?>"></i></div>
        	<?php endif; ?>

        	<?php if ( $instance['title'] ) : ?>
        	<h3 class="folder-title">
        		<?php if ( '' !== $instance['title_link'] ) : ?>
        			<a href="<?php echo esc_url( $instance['title_link'] ); ?>"><?php echo esc_html( $instance['title'] ); ?></a>
        		<?php else : ?>
        			<?php echo esc_html( $instance['title'] ); ?>
        		<?php endif; ?>
        	</h3>
        	<?php endif; ?>

        	<?php if ( '' !== $instance['text'] ) : ?>
        	<div class="folder-text">
        		<?php echo wpautop( $instance['text'] ); ?>
        	</div>
        	<?php endif; ?>

        	<?php if ( '' !== $instance['links'] ) : ?>
    		<ul class="folder-links">
        		<?php foreach ( $instance['links'] as $link ) : ?>
        			<?php if ( is_array( $link ) && 2 === count( $link ) ) : ?>
    				<li><a href="<?php echo esc_url( $link[1] ); ?>"><?php echo esc_html( $link[0] ); ?></a></li>
    				<?php endif; ?>
        		<?php endforeach; ?>
    		</ul>
        	<?php endif; ?>

        </div>
		<?php echo $args['after_widget']; ?>

        <?php

    }

}}

?>