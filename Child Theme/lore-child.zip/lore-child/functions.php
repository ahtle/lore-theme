<?php add_action( 'after_setup_theme', 'lsvr_lore_child_theme_setup' );
if ( ! function_exists( 'lsvr_lore_child_theme_setup' ) ) {
	function lsvr_lore_child_theme_setup() {

		/**
		 * Load text domain
		 *
		 * @link https://codex.wordpress.org/Function_Reference/load_theme_textdomain
		 */
		load_theme_textdomain( 'lore', get_stylesheet_directory() . '/languages' );

		/**
		 * Load parent and child style.css
		 *
		 * @link https://codex.wordpress.org/Child_Themes#How_to_Create_a_Child_Theme
		 */
		add_action( 'wp_enqueue_scripts', 'lsvr_lore_child_enqueue_parent_styles' );
		if ( ! function_exists( 'lsvr_lore_child_enqueue_parent_styles' ) ) {
			function lsvr_lore_child_enqueue_parent_styles() {
				wp_enqueue_style( 'lsvr-lore-main-style', get_template_directory_uri() . '/style.css' );
				wp_enqueue_style( 'lsvr-lore-child-style', get_stylesheet_directory_uri() . '/style.css', array( 'lsvr-lore-main-style' ) );
			}
		}

		/**
		 * Load custom JavaScript file
		 *
		 * Add your custom JS into library/js/child-scripts.js file
		 */
		//add_action( 'wp_enqueue_scripts', 'lsvr_lore_child_load_scripts' );  // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_load_scripts' ) ) {
			function lsvr_lore_child_load_scripts() {
				$theme = wp_get_theme();
				$theme_version = $theme->Version;
				wp_register_script( 'lsvr-lore-child-scripts', get_stylesheet_directory_uri() . '/library/js/child-scripts.js', array('jquery'), $theme_version, true );
				wp_enqueue_script( 'lsvr-lore-child-scripts' );
			}
		}

		/* Place your code here */

		/** Theme hooks
		 *
		 * Feel free to remove any of the code blocks below if you don't feel like using them
		 * they are not needed for theme to work, but they may come handy in some situations
		 *
		 * @link http://codex.wordpress.org/Glossary#Filter
		 * @link http://codex.wordpress.org/Glossary#Action
		 */

		/**
		 * Override post type icons
		 *
		 * Change icons for post types which are displayed in search results
		 * You can find list of all bundled icons and their classes in documentation
		 * Icons for Knowledge Base articles acn be overriden with the "lsvr_lore_kb_post_format_icons" hook below
		 */
		//add_action( 'lsvr_lore_post_type_icons', 'lsvr_lore_post_type_icons_custom' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_post_type_icons_custom' ) ) {
			function lsvr_lore_post_type_icons_custom() {

				return $post_type_icons_defaults = array(
					'lsvr_lore_faq' => 'loreico loreico-bubble-question', // FAQ post
					'post' => 'loreico loreico-document2', // Standard blog post
					'page' => 'loreico loreico-file', // Page or other
					'forum' => 'loreico loreico-bubbles', // bbPress forum
					'topic' => 'loreico loreico-bubbles', // bbPress topic
					'reply' => 'loreico loreico-bubbles', // bbPress reply
				);

			}
		}

		/**
		 * Override Knowledge Base post format icons
		 *
		 * You can find list of all bundled icons and their classes in documentation
		 */
		//add_action( 'lsvr_lore_kb_post_format_icons', 'lsvr_lore_child_kb_post_format_icons_custom' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_kb_post_format_icons_custom' ) ) {
			function lsvr_lore_child_kb_post_format_icons_custom() {

				return array(
					'default' => 'loreico loreico-document',
					'gallery' => 'loreico loreico-picture2',
					'link' => 'loreico loreico-link',
					'image' => 'loreico loreico-camera',
					'video' => 'loreico loreico-film-play',
					'audio' => 'loreico loreico-music-note',
				);

			}
		}

		/**
		 * Override Knowledge Base post attachment icons
		 *
		 * You can find list of all bundled icons and their classes in documentation
		 */
		//add_action( 'lsvr_lore_post_attachment_icons', 'lsvr_lore_child_post_attachment_icons_custom' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_post_attachment_icons_custom' ) ) {
			function lsvr_lore_child_post_attachment_icons_custom() {

				return array(
					'default' => 'loreico loreico-link',
					'image' => 'loreico loreico-picture',
					'video' => 'loreico loreico-film-play',
					'audio' => 'loreico loreico-music-note',
					'msword' => 'loreico loreico-file-word-o',
					'pdf' => 'loreico loreico-file-pdf-o',
				);

			}
		}

		/**
		 * Header search filter hook
		 *
		 * Add your own CPT to search filter
		 */
		//add_action( 'lsvr_lore_header_search_filter_items_after', 'lsvr_lore_child_header_search_filter_custom' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_header_search_filter_custom' ) ) {
			function lsvr_lore_child_header_search_filter_custom() {

				lsvr_lore_header_search_filter_add_item( 'cpt_name', __( 'CPT Label', 'lore' ) ); // duplicate this line for each CPT

			}
		}

		/**
		 * Show large header search on specific pages
		 *
		 * This filter basically overrides/extends Customizer / Header Search / Large Header Search options
		 */
		//add_filter( 'lsvr_lore_has_large_header_search', 'lsvr_lore_child_has_large_header_search' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_has_large_header_search' ) ) {
			function lsvr_lore_child_has_large_header_search( $default ) {

				// This example will display large header search for pages with specific IDs
				global $post;
				$pages = array( 10, 20, 123 ); // Add page IDs to this array
				if ( is_page() && ! empty( $post->ID ) && in_array( $post->ID, $pages ) ) {
					return true; // Set to false if you want to hide the large search for those pages (compact version will be displayed instead)
				}

			}
		}

		/**
		 * Override post title settings
		 *
		 * Add your own (or 3rd party) CPTs to override the title on CPT archive page
		 */
		//add_filter( 'lsvr_lore_page_title_args', 'lsvr_lore_child_page_title_args_override' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_page_title_args_override' ) ) {
			function lsvr_lore_child_page_title_args_override() {
				return array(
					'post_types' => array(
						'your_cpt' => __( 'Your CPT Title', 'lore' ),
					)
				);
			}
		}

		/**
		 * Override breadcrumbs settings
		 *
		 * Add your own (or 3rd party) CPTs and Taxonomies to properly include them in breadcrumbs
		 */
		//add_filter( 'lsvr_lore_breadcrumbs_args', 'lsvr_lore_child_breadcrumbs_args_override' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_breadcrumbs_args_override' ) ) {
			function lsvr_lore_child_breadcrumbs_args_override() {
				return array(
					'post_types' => array(
						'your_cpt' => __( 'Your CPT Title', 'lore' ),
					),
					'taxonomies' => array(
						'your_taxonomy' => 'your_cpt', // pair your taxonomy with its CPT
					),
					'show_home_link' => true,
					'home_link_label' => __( 'Home', 'lore' ),
					'show_on_front_page' => false,
					'show_last' => false, // show the last breadcrumbs item (which is just duplicate of page title)
					'show_single' => false // show breadcrumbs even if it consists only from a single item
				);
			}
		}

		/**
		 * Add custom code before page header
		 */
		//add_action( 'lsvr_lore_header_before', 'lsvr_lore_child_header_before' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_header_before' ) ) {
			function lsvr_lore_child_header_before() { ?>

				<?php _e( 'I am text before header', 'lore' ); ?>

			<?php }
		}

		/**
		 * Add custom code before header menu
		 *
		 * Please note that all menu elements (menu, language switcher, search button) are floated to the right (via CSS)
		 * which means they are created in a reversed order in the DOM compared to visible order seen on the page.
		 * This hook will place your code before other elements, so if you want it to appear as the last one, float it to the right as well
		 */
		//add_action( 'lsvr_lore_header_menu_before', 'lsvr_lore_child_header_menu_before' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_header_menu_before' ) ) {
			function lsvr_lore_child_header_menu_before() { ?>

				<?php _e( 'I am text before header menu', 'lore' ); ?>

			<?php }
		}

		/**
		 * Add custom code after page header
		 */
		//add_action( 'lsvr_lore_header_after', 'lsvr_lore_child_header_after' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_header_after' ) ) {
			function lsvr_lore_child_header_after() { ?>

				<?php _e( 'I am text after header', 'lore' ); ?>

			<?php }
		}

		/**
		 * Add custom code before main content of the page
		 */
		//add_action( 'lsvr_lore_main_before', 'lsvr_lore_child_main_before' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_main_before' ) ) {
			function lsvr_lore_child_main_before() { ?>

				<?php _e( 'I am text before main content', 'lore' ); ?>

			<?php }
		}

		/**
		 * Add custom code after main content of the page
		 */
		//add_action( 'lsvr_lore_main_after', 'lsvr_lore_child_main_after' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_main_after' ) ) {
			function lsvr_lore_child_main_after() { ?>

				<?php _e( 'I am text after main content', 'lore' ); ?>

			<?php }
		}

		/**
		 * Add custom code before page footer
		 */
		//add_action( 'lsvr_lore_footer_before', 'lsvr_lore_child_footer_before' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_footer_before' ) ) {
			function lsvr_lore_child_footer_before() { ?>

				<?php _e( 'I am text before footer', 'lore' ); ?>

			<?php }
		}

		/**
		 * Add custom code before footer widgets
		 */
		//add_action( 'lsvr_lore_footer_widgets_before', 'lsvr_lore_child_footer_widgets_before' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_footer_widgets_before' ) ) {
			function lsvr_lore_child_footer_widgets_before() { ?>

				<?php _e( 'I am text before footer widgets', 'lore' ); ?>

			<?php }
		}

		/**
		 * Sanitize shortcodes
		 *
		 * Remove P and BR tags from shortcode tags
		 */
		//add_filter( 'lsvr_toolkit_lore_sanitized_shortcodes', 'lsvr_lore_child_sanitize_shortcodes' ); // uncomment this line before use
		if ( ! function_exists( 'lsvr_lore_child_sanitize_shortcodes' ) ) {
			function lsvr_lore_child_sanitize_shortcodes() {
				return array( 'your_shortcode_name', 'another_shortcode_name' );
			}
		}

	}
} ?>