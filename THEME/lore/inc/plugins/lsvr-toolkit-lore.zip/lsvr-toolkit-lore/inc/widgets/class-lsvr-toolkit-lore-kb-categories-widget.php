<?php
/**
 * Knowledge Base categories widget
 *
 * Display list of Knowledge Base categories
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_KB_Categories_Widget' ) ) {
class Lsvr_Toolkit_Lore_KB_Categories_Widget extends WP_Widget {

    protected $defaults;

    public function __construct() {
        $widget_ops = array(
            'classname' => 'lsvr-kb-categories',
            'description' => esc_html__( 'List Knowledge Base categories', 'lsvr-toolkit-lore' ),
        );
        parent::__construct( 'lsvr_lore_kb_categories_widget', esc_html__( 'Lore Knowledge Base Categories', 'lsvr-toolkit-lore' ), $widget_ops );
        $this->defaults = array(
            'title' => esc_html__( 'Categories', 'lsvr-toolkit-lore' ),
            'show_count' => 'on',
            'show_articles' => 'on',
        );
    }

    function form( $instance ) {

        $instance = wp_parse_args( (array) $instance, $this->defaults );

        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'lsvr-toolkit-lore' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>

		<p>
			<input class="checkbox" type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_count' ) ); ?>" <?php if ( 'on' === $instance['show_count'] ) { echo ' checked'; } ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_count' ) ); ?>"><?php echo esc_html__( 'Show Article Count', 'lsvr-toolkit-lore' ); ?></label>
        </p>

        <p>
            <input class="checkbox" type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_articles' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_articles' ) ); ?>" <?php if ( 'on' === $instance['show_articles'] ) { echo ' checked'; } ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_articles' ) ); ?>"><?php echo esc_html__( 'Show Articles', 'lsvr-toolkit-lore' ); ?></label>
        </p>

        <?php

    }

    function update( $new_instance, $old_instance ) {

        $instance = $old_instance;

        $instance['title'] = $new_instance['title'];
		$instance['show_count'] = $new_instance['show_count'];
        $instance['show_articles'] = $new_instance['show_articles'];
        return $instance;

    }

    function widget( $args, $instance ) {

        $instance = empty( $instance ) ? wp_parse_args( (array) $instance, $this->defaults ) : $instance;
        $instance['title'] = apply_filters( 'widget_title', $instance['title'] );
        $instance['show_count'] = 'on' === $instance['show_count'] ? true : false;
        $instance['show_articles'] = 'on' === $instance['show_articles'] ? true : false;

        ?>

		<?php echo $args['before_widget']; ?>
        <?php if ( '' !== $instance['title'] ) { echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; } ?>
        <div class="widget-content">

            <?php $current_term_id = false;
            if ( is_singular( 'lsvr_lore_kb' ) ) {
                global $post;
                $article_terms = wp_get_post_terms( $post->ID, 'lsvr_lore_kb_cat' );
                if ( is_array( $article_terms ) && count( $article_terms ) > 0 ) {
                    $current_term = reset( $article_terms );
                    if ( is_object( $current_term ) && property_exists( $current_term, 'term_id' ) ) {
                        $current_term_id = $current_term->term_id;
                    }
                }
            } ?>

            <?php // Query args
            $query_args = array(
                'taxonomy' => 'lsvr_lore_kb_cat',
                'show_count' => $instance['show_count'],
                'show_articles' => $instance['show_articles'],
                'title_li' => '',
                'show_option_none' => '<p class="no-categories">' . esc_html__( 'No categories', 'lsvr-toolkit-lore' ) . '</p>',
                'walker' => new Lsvr_Toolkit_Lore_KB_Categories_Walker,
            );
            if ( $current_term_id ) {
                $query_args['current_category'] = $current_term_id;
            } ?>

			<ul class="root-level">
            <?php wp_list_categories( $query_args ); ?>
			</ul>

        </div>
		<?php echo $args['after_widget']; ?>

        <?php

    }

}}

?>