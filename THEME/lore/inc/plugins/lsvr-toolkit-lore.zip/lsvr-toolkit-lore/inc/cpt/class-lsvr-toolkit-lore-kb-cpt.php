<?php
/**
 * FAQ post type class
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_KB_CPT' ) && class_exists( 'Lsvr_Toolkit_Lore_CPT' ) ) {
    class Lsvr_Toolkit_Lore_KB_CPT extends Lsvr_Toolkit_Lore_CPT {

		public function __construct(){

			parent::__construct( 'lsvr_lore_kb', array(
				'labels' => array(
					'name' => esc_html__( 'Knowledge Base', 'lsvr-toolkit-lore' ),
					'singular_name' => esc_html__( 'Knowledge Base', 'lsvr-toolkit-lore' ),
					'add_new' => esc_html__( 'Add New Article', 'lsvr-toolkit-lore' ),
					'add_new_item' => esc_html__( 'Add New Article', 'lsvr-toolkit-lore' ),
					'edit_item' => esc_html__( 'Edit Article', 'lsvr-toolkit-lore' ),
					'new_item' => esc_html__( 'Add New Article', 'lsvr-toolkit-lore' ),
					'view_item' => esc_html__( 'View Article', 'lsvr-toolkit-lore' ),
					'search_items' => esc_html__( 'Search articles', 'lsvr-toolkit-lore' ),
					'not_found' => esc_html__( 'No articles found', 'lsvr-toolkit-lore' ),
					'not_found_in_trash' => esc_html__( 'No articles found in trash', 'lsvr-toolkit-lore' ),
				),
				'exclude_from_search' => false,
				'public' => true,
				'supports' => array( 'title', 'editor', 'custom-fields', 'revisions', 'excerpt', 'comments', 'post-formats' ),
				'capability_type' => 'post',
				'rewrite' => array( 'slug' => get_theme_mod( 'kb_slug', 'knowledge-base' ) ),
				'menu_position' => 5,
				'has_archive' => true,
				'show_in_nav_menus' => true,
				'menu_icon' => 'dashicons-book',
			));

			// Add KB Category taxonomy
			$this->add_taxonomy( 'lsvr_lore_kb_cat', array(
				'labels' => array(
					'name' => esc_html__( 'Knowledge Base Categories', 'lsvr-toolkit-lore' ),
					'singular_name' => esc_html__( 'Category', 'lsvr-toolkit-lore' ),
					'search_items' => esc_html__( 'Search Categories', 'lsvr-toolkit-lore' ),
					'popular_items' => esc_html__( 'Popular Categories', 'lsvr-toolkit-lore' ),
					'all_items' => esc_html__( 'All Categories', 'lsvr-toolkit-lore' ),
					'parent_item' => esc_html__( 'Parent Category', 'lsvr-toolkit-lore' ),
					'parent_item_colon' => esc_html__( 'Parent Category:', 'lsvr-toolkit-lore' ),
					'edit_item' => esc_html__( 'Edit Category', 'lsvr-toolkit-lore' ),
					'update_item' => esc_html__( 'Update Category', 'lsvr-toolkit-lore' ),
					'add_new_item' => esc_html__( 'Add New Category', 'lsvr-toolkit-lore' ),
					'new_item_name' => esc_html__( 'New Category Name', 'lsvr-toolkit-lore' ),
					'separate_items_with_commas' => esc_html__( 'Separate categories with commas', 'lsvr-toolkit-lore' ),
					'add_or_remove_items' => esc_html__( 'Add or remove categories', 'lsvr-toolkit-lore' ),
					'choose_from_most_used' => esc_html__( 'Choose from the most used categories', 'lsvr-toolkit-lore' ),
					'menu_name' => esc_html__( 'Categories', 'lsvr-toolkit-lore' )
				),
				'public' => true,
				'show_in_nav_menus' => true,
				'show_ui' => true,
				'show_admin_column' => true,
				'show_tagcloud' => true,
				'hierarchical' => true,
				'rewrite' => array( 'slug' => get_theme_mod( 'kb_cat_slug', 'knowledge-base-category' ) ),
				'query_var' => true
			), true );

			// Add KB Tag taxonomy
			$this->add_taxonomy( 'lsvr_lore_kb_tag', array(
				'labels' => array(
					'name' => esc_html__( 'Knowledge Base Tags', 'lsvr-toolkit-lore' ),
					'singular_name' => esc_html__( 'Tag', 'lsvr-toolkit-lore' ),
					'search_items' => esc_html__( 'Search Tags', 'lsvr-toolkit-lore' ),
					'popular_items' => esc_html__( 'Popular Tags', 'lsvr-toolkit-lore' ),
					'all_items' => esc_html__( 'All Tags', 'lsvr-toolkit-lore' ),
					'parent_item' => esc_html__( 'Parent Tag', 'lsvr-toolkit-lore' ),
					'parent_item_colon' => esc_html__( 'Parent Tag:', 'lsvr-toolkit-lore' ),
					'edit_item' => esc_html__( 'Edit Tag', 'lsvr-toolkit-lore' ),
					'update_item' => esc_html__( 'Update Tag', 'lsvr-toolkit-lore' ),
					'add_new_item' => esc_html__( 'Add New Tag', 'lsvr-toolkit-lore' ),
					'new_item_name' => esc_html__( 'New Tag Name', 'lsvr-toolkit-lore' ),
					'separate_items_with_commas' => esc_html__( 'Separate tags with commas', 'lsvr-toolkit-lore' ),
					'add_or_remove_items' => esc_html__( 'Add or remove tags', 'lsvr-toolkit-lore' ),
					'choose_from_most_used' => esc_html__( 'Choose from the most used tags', 'lsvr-toolkit-lore' ),
					'menu_name' => esc_html__( 'Tags', 'lsvr-toolkit-lore' )
				),
				'public' => true,
				'show_in_nav_menus' => true,
				'show_ui' => true,
				'show_admin_column' => true,
				'show_tagcloud' => true,
				'hierarchical' => false,
				'rewrite' => array( 'slug' => get_theme_mod( 'kb_tag_slug', 'knowledge-base-tag' ) ),
				'query_var' => true
			), true );

			// Init custom taxonomy field for icon
			add_action( 'lsvr_lore_kb_cat_add_form_fields', array( $this, 'add_meta_fields' ), 10, 2 );
			add_action( 'lsvr_lore_kb_cat_edit_form_fields', array( $this, 'edit_meta_fields' ), 10, 2 );
			add_action( 'edited_lsvr_lore_kb_cat', array( $this, 'save_meta_fields' ), 10, 2 );
			add_action( 'create_lsvr_lore_kb_cat', array( $this, 'save_meta_fields' ), 10, 2 );

			// Add rating summary column
			if ( true == get_theme_mod( 'kb_rating_enable', true ) ) {
				add_filter( 'manage_edit-lsvr_lore_kb_columns', array( $this, 'add_admin_post_rating_column' ), 10, 1 );
				add_action( 'manage_posts_custom_column', array( $this, 'display_admin_post_rating_column' ), 10, 1 );
			}

		}

		/**
		 * Custom taxonomy field for icon
		 *
		 * @link https://pippinsplugins.com/adding-custom-meta-fields-to-taxonomies/
		 */
		public function add_meta_fields() { ?>
			<div class="form-field">
				<label for="lsvr_lore_kb_term_meta[category_icon_meta]"><?php esc_html_e( 'Category Icon', 'lsvr-toolkit-lore' ); ?></label>
				<input type="text" name="lsvr_lore_kb_term_meta[category_icon_meta]" id="lsvr_lore_kb_term_meta[category_icon_meta]" value="">
				<p class="description"><?php esc_html_e( 'Name of the icon (e.g. "loreico loreico-heart"). Please refer to the documentation to learn more about using the icons.','lsvr-toolkit-lore' ); ?></p>
			</div>
		<?php }

		public function edit_meta_fields( $term ) { ?>
			<?php $t_id = $term->term_id;
			$term_meta = get_option( 'taxonomy_' . $t_id ); ?>
			<tr class="form-field">
				<th scope="row" valign="top"><label for="lsvr_lore_kb_term_meta[category_icon_meta]"><?php esc_html_e( 'Category Icon', 'lsvr-toolkit-lore' ); ?></label></th>
				<td>
					<input type="text" name="lsvr_lore_kb_term_meta[category_icon_meta]" id="lsvr_lore_kb_term_meta[category_icon_meta]" value="<?php echo esc_attr( $term_meta['category_icon_meta'] ) ? esc_attr( $term_meta['category_icon_meta'] ) : ''; ?>">
					<p class="description"><?php esc_html_e( 'Name of the icon (e.g. "loreico loreico-heart"). Please refer to the documentation to learn more about using the icons.','lsvr-toolkit-lore' ); ?></p>
				</td>
			</tr>
		<?php }

		public function save_meta_fields( $term_id ) {
			if ( isset( $_POST['lsvr_lore_kb_term_meta'] ) ) {
				$t_id = $term_id;
				$term_meta = get_option( 'taxonomy_' . $t_id );
				$cat_keys = array_keys( $_POST['lsvr_lore_kb_term_meta'] );
				foreach ( $cat_keys as $key ) {
					if ( isset ( $_POST['lsvr_lore_kb_term_meta'][ $key ] ) ) {
						$term_meta[$key] = $_POST['lsvr_lore_kb_term_meta'][ $key ];
					}
				}
				update_option( 'taxonomy_' . $t_id, $term_meta );
			}
		}

		/**
		 * Add rating summary
		 *
		 * Show likes and dislikes for the article in admin listing
		 */
		public function add_admin_post_rating_column( $columns ) {
			$column_rating = array( 'rating' => esc_html__( 'Rating', 'lsvr-toolkit-lore' ) );
			$columns = array_slice( $columns, 0, 2, true ) + $column_rating + array_slice( $columns, 1, NULL, true );
			return $columns;
		}
		public function display_admin_post_rating_column( $column ) {
			global $post;
			global $typenow;
			if ( $typenow == $this->post_type) {
				$likes = '' !== get_post_meta( $post->ID, 'lsvr_lore_likes_count', true ) ? (int) get_post_meta( $post->ID, 'lsvr_lore_likes_count', true ) : 0;
				$dislikes = '' !== get_post_meta( $post->ID, 'lsvr_lore_dislikes_count', true ) ? (int) get_post_meta( $post->ID, 'lsvr_lore_dislikes_count', true ) : 0;
				switch ( $column ) {
					case 'rating':
						echo esc_html( $likes ) . ' ' . esc_html__( 'likes', 'lsvr-toolkit-lore' );
						echo true == get_theme_mod( 'kb_rating_dislikes_enable', true ) ? '<br>' . esc_html( $dislikes ) . ' ' . esc_html__( 'dislikes', 'lsvr-toolkit-lore' ) : '';
						break;
				}
			}
		}

    }
}
?>