<?php
/**
 * Table of contents
 *
 * Create table of contents with anchor links to all heading elements with ID attribute
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Contents_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Contents_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_contents', array(
                'title' => esc_html__( 'Contents', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'Create table of contents with anchor links to all heading elements (h1, h2, h3...) with ID attribute', 'lsvr-toolkit-lore' ),
                'atts' => array(
                    'title' => array(
                        'label' => esc_html__( 'Title', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Leave blank to hide title', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'excluded_ids' => array(
                        'label' => esc_html__( 'Excluded IDs', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Elements with these IDs will be ignored. Separate with comma', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'title' => '',
                    'excluded_ids' => '',
                    'custom_class' => '',
                ),
                $atts
            );

            $atts['excluded_ids'] = str_replace( ', ', ',', esc_attr( $atts['excluded_ids'] ) );

            $class_arr[] = $atts['custom_class'];
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <div class="c-contents<?php echo esc_attr( $class ); ?>"
                <?php if ( '' !== $atts['excluded_ids'] ) : ?>
                data-excluded-ids="<?php echo esc_attr( $atts['excluded_ids'] ); ?>"
                <?php endif; ?>
                style="display: none;">
                <div class="contents-inner">
                    <?php if ( '' !== $atts['title'] ) : ?>
                    <h6 class="contents-title"><span><?php echo esc_html( $atts['title'] ); ?></span></h6>
                    <?php endif; ?>
                </div>
            </div>

            <?php return ob_get_clean();

        }

    }
}
?>