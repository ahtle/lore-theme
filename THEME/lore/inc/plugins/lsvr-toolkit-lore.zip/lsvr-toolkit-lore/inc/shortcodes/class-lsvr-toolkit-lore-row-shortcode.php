<?php
/**
 * Row
 *
 * Container for Column shortcodes
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Row_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Row_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_row', array(
                'title' => esc_html__( 'Row', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'Container for Column shortcodes', 'lsvr-toolkit-lore' ),
                'paired' => true,
                'atts' => array(
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'title' => '',
                    'icon' => '',
                    'custom_class' => '',
                ),
                $atts
            );

            $class_arr[] = $atts['custom_class'];
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <div class="row<?php echo esc_attr( $class ); ?>">
                <?php echo do_shortcode( $content ); ?>
            </div>

            <?php return ob_get_clean();

        }

    }
}
?>