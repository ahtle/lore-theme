<?php
/**
 * Google Map
 *
 * Google API key is required for map to work
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Gmap_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Gmap_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_gmap', array(
                'title' => esc_html__( 'Google Map', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'Simple Google map', 'lsvr-toolkit-lore' ),
                'atts' => array(
                    'apikey' => array(
                        'label' => esc_html__( 'Google API Key', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'API key is required for this map to work.', 'lsvr-toolkit-lore' ) . '<br><a href="https://developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">https://developers.google.com/maps/documentation/javascript/get-api-key</a>',
                        'type' => 'text',
                    ),
                    'address' => array(
                        'label' => esc_html__( 'Address', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'For example: 8833 Sunset Blvd, West Hollywood, CA 90069, USA', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'latitude' => array(
                        'label' => esc_html__( 'Latitude', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Optional, it can be more precise than using just the address. For example: 40.724741', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'longitude' => array(
                        'label' => esc_html__( 'Longitude', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Optional, it can be more precise than using just the address. For example: -73.994797', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'type' => array(
                        'label' => esc_html__( 'Map Type', 'lsvr-toolkit-lore' ),
                        'values' => array( 'roadmap' => esc_html__( 'Roadmap', 'lsvr-toolkit-lore' ), 'satellite' => esc_html__( 'Satellite', 'lsvr-toolkit-lore' ), 'terrain' => esc_html__( 'Terrain', 'lsvr-toolkit-lore' ), 'hybrid' => esc_html__( 'Hybrid', 'lsvr-toolkit-lore' ) ),
                        'type' => 'select',
                        'default' => 'satellite',
                    ),
                    'zoom' => array(
                        'label' => __( 'Zoom Level', 'lsvr-toolkit-lore' ),
                        'values' => array( '16' => esc_html__( 'Very Far', 'lsvr-toolkit-lore' ), '17' => esc_html__( 'Far', 'lsvr-toolkit-lore' ), '18' => esc_html__( 'Close', 'lsvr-toolkit-lore' ), '19' => esc_html__( 'Very Close', 'lsvr-toolkit-lore' ) ),
                        'type' => 'select',
                        'default' => '18',
                    ),
                    'height' => array(
                        'label' => esc_html__( 'Height', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Value in pixels, for example "200" (without quotes)', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                        'default' => '360',
                    ),
                    'fullwidth' => array(
                        'label' => __( 'Full Width', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Stretch the map to full width of content', 'lsvr-toolkit-lore' ),
                        'values' => array( 'yes' => esc_html__( 'Yes', 'lsvr-toolkit-lore' ), 'no' => esc_html__( 'No', 'lsvr-toolkit-lore' ) ),
                        'type' => 'select',
                        'default' => 'no',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'apikey' => '',
                    'address' => '',
                    'latitude' => '',
                    'longitude' => '',
                    'type' => 'satellite',
                    'zoom' => '18',
                    'height' => '360',
                    'fullwidth' => 'no',
                    'custom_class' => '',
                ),
                $atts
            );

            $class_arr[] = $atts['custom_class'];
            $class_arr[] = 'yes' === $atts['fullwidth'] ? 'm-fullwidth' : '';
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <?php if ( empty( $atts['apikey'] ) || esc_html__( 'PUT-YOUR-GOOGLE-API-KEY-HERE' ,'lsvr-toolkit-lore' ) === $atts['apikey']  ) : ?>

                <p class="c-alert-message"><?php echo esc_html__( 'Google API key is required for Google Map to work. Put your API key into "apikey" attribute of lore_gmap shortcode', 'lsvr-toolkit-lore' ); ?></p>

            <?php else : ?>

                <div class="c-gmap<?php echo esc_attr( $class ); ?>">
                    <div class="gmap-canvas"
                        style="height: <?php echo esc_attr( $atts['height'] ); ?>px"
                        <?php if ( ! empty( $atts['apikey'] ) ) : ?>data-apikey="<?php echo esc_attr( $atts['apikey'] ); ?>"<?php endif; ?>
                        <?php if ( ! empty( $atts['address'] ) ) : ?>data-address="<?php echo esc_attr( $atts['address'] ); ?>"<?php endif; ?>
                        <?php if ( ! empty( $atts['latitude'] ) ) : ?>data-latitude="<?php echo esc_attr( $atts['latitude'] ); ?>"<?php endif; ?>
                        <?php if ( ! empty( $atts['longitude'] ) ) : ?>data-longitude="<?php echo esc_attr( $atts['longitude'] ); ?>"<?php endif; ?>
                        data-zoom="<?php echo esc_attr( $atts['zoom'] ); ?>"
                        data-type="<?php echo esc_attr( $atts['type'] ); ?>"
                        data-enable-mousewheel="false">
                    </div>
                </div>

            <?php endif; ?>

            <?php return ob_get_clean();

        }

    }
}
?>