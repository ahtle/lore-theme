<?php
/**
 * Shortcode Generator class
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Shortcode_Generator' ) ) {
	class Lsvr_Toolkit_Lore_Shortcode_Generator {

		public $args;
		public $js_strings;
        public $prefix = 'lsvr_toolkit';

		public function __construct( $args ) {

			$this->args = ! empty( $args ) ? $args : [];
            $this->prefix = ! empty( $this->args['prefix'] ) ? $this->args['prefix'] : $this->prefix;
			$this->js_strings = ! empty( $this->args['js_strings'] ) ? $this->args['js_strings'] : [];

			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			add_filter( 'admin_footer', array( $this, 'output_data' ) );
			add_action( 'media_buttons', array( $this, 'add_button' ), 11 );

		}

		/**
		 * Create JS vars with essential data
		 */
		public function output_data() {

    		global $shortcode_tags;

    		// Create a big array with all shortcodes and their respective attributes
    		$shortcodes_list_data = [];
    		foreach ( $shortcode_tags as $shortcode_name => $shortcode_arr ) {
    			if ( 'lore_' === strtolower( substr( $shortcode_name, 0, 5 ) ) &&
                        is_array( $shortcode_arr ) && is_string( $shortcode_arr[0] ) && class_exists( $shortcode_arr[0] ) ) {

                    $shortcode_obj = new $shortcode_arr[0];
                    $shortcodes_list_data = array_merge( $shortcodes_list_data, $shortcode_obj->get_shortcode_data() );

    			}
    		}

            // Init shortcode generator
            if ( ! empty( $shortcodes_list_data ) ) {
            ?><script type="text/javascript">
            jQuery(document).ready(function(){
                if ( jQuery.fn.lsvrToolkitShortcodeGenerator ){

                    // Create JSON var
                    <?php ksort( $shortcodes_list_data );
                    echo 'var ' . $this->prefix . '_shortcodes = ' . json_encode( $shortcodes_list_data ) . ';'; ?>

                    // Translatable JS strings
                    var <?php echo esc_attr( $this->prefix ); ?>_sg_js_strings = {};
                    <?php echo esc_attr( $this->prefix ); ?>_sg_js_strings.modal_title = '<?php echo ! empty( $this->js_strings["modal_title"] ) ? esc_attr( $this->js_strings["modal_title"] ) : ""; ?>';
                    <?php echo esc_attr( $this->prefix ); ?>_sg_js_strings.choose_sc = '<?php echo ! empty( $this->js_strings["choose_sc"] ) ? esc_attr( $this->js_strings["choose_sc"] ) : ""; ?>';
                    <?php echo esc_attr( $this->prefix ); ?>_sg_js_strings.select_images_btn = '<?php echo ! empty( $this->js_strings["select_images_btn"] ) ? esc_attr( $this->js_strings["select_images_btn"] ) : ""; ?>';
                    <?php echo esc_attr( $this->prefix ); ?>_sg_js_strings.code_preview_label = '<?php echo ! empty( $this->js_strings["code_preview_label"] ) ? esc_attr( $this->js_strings["code_preview_label"] ) : ""; ?>';
                    <?php echo esc_attr( $this->prefix ); ?>_sg_js_strings.code_preview_placeholder = '<?php echo ! empty( $this->js_strings["code_preview_placeholder"] ) ? esc_attr( $this->js_strings["code_preview_placeholder"] ) : ""; ?>';
                    <?php echo esc_attr( $this->prefix ); ?>_sg_js_strings.add_sc_btn = '<?php echo ! empty( $this->js_strings["add_sc_btn"] ) ? esc_attr( $this->js_strings["add_sc_btn"] ) : ""; ?>';

                    jQuery( '.<?php echo esc_attr( $this->prefix ); ?>-shortcode-generator-button' ).each(function(){
                        jQuery(this).lsvrToolkitShortcodeGenerator( <?php echo esc_attr( $this->prefix ); ?>_shortcodes, <?php echo esc_attr( $this->prefix ); ?>_sg_js_strings );
                    });

                }
            });
            </script><?php
            }

		}

	    /**
	     * Add Shortcode Generator button to content editor
	     */
        function add_button(){
            ?>
            <button type="button" class="<?php echo esc_attr( $this->prefix ); ?>-shortcode-generator-button lsvr-toolkit-shortcode-generator-button button">
                <span class="dashicons dashicons-plus"></span><?php echo ! empty( $this->args['add_sg_button_label'] ) ? esc_html( $this->args['add_sg_button_label'] ) : ''; ?>
            </button>
            <?php
        }

	}
} ?>