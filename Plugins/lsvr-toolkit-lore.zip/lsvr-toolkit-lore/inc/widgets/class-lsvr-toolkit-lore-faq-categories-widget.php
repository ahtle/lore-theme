<?php
/**
 * FAQ categories widget
 *
 * Display list of FAQ post categories
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_FAQ_Categories_Widget' ) ) {
class Lsvr_Toolkit_Lore_FAQ_Categories_Widget extends WP_Widget {

    protected $defaults;

    public function __construct() {
        $widget_ops = array(
            'classname' => 'lsvr-faq-categories',
            'description' => esc_html__( 'List FAQ categories', 'lsvr-toolkit-lore' ),
        );
        parent::__construct( 'lsvr_lore_faq_categories_widget', esc_html__( 'Lore FAQ Categories', 'lsvr-toolkit-lore' ), $widget_ops );
        $this->defaults = array(
            'title' => esc_html__( 'Categories', 'lsvr-toolkit-lore' ),
            'show_count' => 'on',
        );
    }

    function form( $instance ) {

        $instance = wp_parse_args( (array) $instance, $this->defaults );

        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'lsvr-toolkit-lore' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" >
        </p>

		<p>
			<input class="checkbox" type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_count' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_count' ) ); ?>" <?php if ( 'on' === $instance['show_count'] ) { echo ' checked'; } ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_count' ) ); ?>"><?php echo esc_html__( 'Show Post Count', 'lsvr-toolkit-lore' ); ?></label>
        </p>

        <?php

    }

    function update( $new_instance, $old_instance ) {

        $instance = $old_instance;

        $instance['title'] = $new_instance['title'];
		$instance['show_count'] = $new_instance['show_count'];
        return $instance;

    }

    function widget( $args, $instance ) {

        $instance = empty( $instance ) ? wp_parse_args( (array) $instance, $this->defaults ) : $instance;
        $instance['title'] = apply_filters( 'widget_title', $instance['title'] );
		$instance['show_count'] = 'on' === $instance['show_count'] ? true : false;

        ?>

		<?php echo $args['before_widget']; ?>
        <?php if ( '' !== $instance['title'] ) { echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; } ?>
        <div class="widget-content">

            <?php $current_term_id = false;
            if ( is_singular( 'lsvr_lore_faq' ) ) {
                global $post;
                $article_terms = wp_get_post_terms( $post->ID, 'lsvr_lore_faq_cat' );
                if ( is_array( $article_terms ) && count( $article_terms ) > 0 ) {
                    $current_term = reset( $article_terms );
                    if ( is_object( $current_term ) && property_exists( $current_term, 'term_id' ) ) {
                        $current_term_id = $current_term->term_id;
                    }
                }
            } ?>

            <?php // Query args
            $query_args = array(
                'taxonomy' => 'lsvr_lore_faq_cat',
                'show_count' => (int) $instance['show_count'],
                'title_li' => '',
            );
            if ( $current_term_id ) {
                $query_args['current_category'] = (int) $current_term_id;
            } ?>

			<ul>
			<?php wp_list_categories( $query_args ); ?>
			</ul>

        </div>
		<?php echo $args['after_widget']; ?>

        <?php

    }

}}
?>