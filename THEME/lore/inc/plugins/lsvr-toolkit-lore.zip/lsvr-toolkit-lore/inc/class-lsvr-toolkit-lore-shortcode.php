<?php
/**
 * Shortcode class
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Shortcode {

		public $shortcode_name;
    	public $shortcode_ops = array(
    		'paired' => false, // if this shortcode is not paired, closing tag is not necessary
			'inline' => false, // if this shortcode is inline, stripping of P tags is not neccessary
			'atts' => [],
		);

        public static $tabs_title_arr = []; // For use with Tabs and Tab Item shortcodes

        public function __construct( $shortcode_name = '', $shortcode_ops = [] ) {
        	$this->shortcode_name = $shortcode_name;
        	$this->shortcode_ops = wp_parse_args( $shortcode_ops, $this->shortcode_ops );
        }

        public function add_att( $args ) {

			$defaults = array(
                'name' => '',
                'atts' => [],
                'add_as_first' => false,
            );
			$args = wp_parse_args( $args, $defaults );

			if ( ! empty( $args['name'] ) && ! empty( $args['atts'] ) ) {
				if ( ! empty( $args['add_as_first'] ) ) {
	        		$this->shortcode_ops['atts'] = array( $args['name'] => $args['atts'] ) + $this->shortcode_ops['atts'];
	        	} else {
	        		$this->shortcode_ops['atts'][ $args['name'] ] = $args['atts'];
	        	}
			}

        }

        public function get_shortcode_data() {
        	return array( $this->shortcode_name => $this->shortcode_ops );
        }

        public function is_inline() {
        	return $this->shortcode_ops['inline'];
        }

    }
}
?>