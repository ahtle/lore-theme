<?php
/**
 * Custom Post Type class
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_CPT' ) ) {
	class Lsvr_Toolkit_Lore_CPT {

		public $args;
		public $post_type;
		public $taxonomies = [];

		public function __construct( $post_type, $args ){

			$this->post_type = sanitize_text_field( $post_type );
			$this->args = is_array( $args ) ? $args : [];

			add_action( 'init', array( $this, 'register_post_type' ) );
			add_action( 'init', array( $this, 'register_taxonomies' ) );
			register_activation_hook( __FILE__, array( $this, 'activate_cpt' ) );

			// Add admin tax filters
			add_action( 'restrict_manage_posts', array( $this, 'add_admin_tax_filters' ) );

		}

		/**
		 * Activate CPT
		 *
		 * This action will be fired once after activation of the plugin
		 */
		public function activate_cpt() {
			$this->register_post_type();
			$this->register_taxonomies();
			flush_rewrite_rules();
		}

		/**
		 * Register post type
		 */
		public function register_post_type(){

			// Register CPT
			register_post_type( $this->post_type, $this->args );

			// Show post thumb in admin listing
			if ( array_key_exists( 'supports', $this->args )
				&& is_array( $this->args['supports'] ) && in_array( 'thumbnail', $this->args['supports'] ) ) {
				add_filter( 'manage_edit-' . $this->post_type . '_columns', array( $this, 'add_admin_post_thumb_column' ), 10, 1 );
				add_action( 'manage_posts_custom_column', array( $this, 'display_admin_post_thumb_column' ), 10, 1 );
			}

		}

		/**
		 * Add taxonomy
		 */
		public function add_taxonomy( $taxonomy, $args, $admin_tax_filter = false ){

			$this->taxonomies[ $taxonomy ]['args'] = $args;

			// Enable admin tax filter
			if ( $admin_tax_filter == true ) {
				$this->taxonomies[ $taxonomy ]['admin_tax_filter'] = true;
			}

		}

		/**
		 * Register taxonomies
		 */
		public function register_taxonomies(){
			foreach( $this->taxonomies as $taxonomy => $taxonomy_arr ) {
				if ( array_key_exists( 'args', $taxonomy_arr ) ) {

					// Register taxonomy
					register_taxonomy( $taxonomy, array( $this->post_type ), $taxonomy_arr['args'] );

				}
			}
		}

		/**
		 * Add admin post thumb column
		 *
		 * Display post thumb in admin post listing
		 *
		 * @link http://wptheming.com/2010/07/column-edit-pages/
		 */
		public function add_admin_post_thumb_column( $columns ) {
			$column_thumbnail = array( 'thumbnail' => '' );
			$columns = array_slice( $columns, 0, 2, true ) + $column_thumbnail + array_slice( $columns, 1, NULL, true );
			return $columns;
		}
		public function display_admin_post_thumb_column( $column ) {
			global $post;
			global $typenow;
			if ( $typenow == $this->post_type) {
				switch ( $column ) {
					case 'thumbnail':
						echo get_the_post_thumbnail( $post->ID, array( 35, 35 ) );
						break;
				}
			}
		}

		/**
		 * Add taxonomy filters to admin
		 *
		 * @link https://pippinsplugins.com/post-list-filters-for-custom-taxonomies-in-manage-posts/
		 */
		public function add_admin_tax_filters(){
			if ( is_array( $this->taxonomies ) && ! empty( $this->taxonomies ) ) {

				global $typenow;

				$taxonomies = array_filter( $this->taxonomies, function( $taxonomy ) {
					return is_array( $taxonomy ) && array_key_exists( 'admin_tax_filter', $taxonomy ) && $taxonomy['admin_tax_filter'];
				});

				if ( $typenow == $this->post_type && ! empty( $taxonomies ) ) {
					foreach ( $taxonomies as $tax_slug => $tax_arr ) {
						$current_tax_slug = isset( $_GET[ $tax_slug ] ) ? $_GET[ $tax_slug ] : false;
						$tax_obj = get_taxonomy( $tax_slug );
						$tax_name = $tax_obj->labels->name;
						$terms = get_terms( $tax_slug );
						if ( count( $terms ) > 0 ) {
							echo '<select name="' . $tax_slug . '" id="' . $tax_slug . '" class="postform">';
							echo '<option value="">' . $tax_name . '</option>';
							foreach ( $terms as $term ) {
								echo '<option value="' . $term->slug . '"';
								echo esc_attr( $current_tax_slug ) === $term->slug ? ' selected="selected"' : '';
								echo '>' . esc_html( $term->name ) . ' (' . esc_html( $term->count ) . ')</option>';
							}
							echo '</select>';
						}
					}
				}

			}
		}

	}
}
?>