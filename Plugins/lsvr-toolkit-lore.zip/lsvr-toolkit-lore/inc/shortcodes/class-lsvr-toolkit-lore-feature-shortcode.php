<?php
/**
 * Feature
 *
 * Block of text with icon and title
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Feature_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Feature_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_feature', array(
                'title' => esc_html__( 'Feature', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'Text block with title and icon', 'lsvr-toolkit-lore' ),
                'paired' => true,
                'atts' => array(
                    'title' => array(
                        'label' => esc_html__( 'Title', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'icon' => array(
                        'label' => esc_html__( 'Icon', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Name of the icon (e.g. "loreico loreico-heart"). Please refer to the documentation to learn more about using the icons', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'title' => '',
                    'icon' => '',
                    'custom_class' => '',
                ),
                $atts
            );

            $class_arr[] = $atts['custom_class'];
            $class_arr[] = ! empty( $atts['icon'] ) ? 'm-has-icon' : '';
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <div class="c-feature<?php echo esc_attr( $class ); ?>">
                <div class="feature-inner">
                    <?php if ( ! empty( $atts['icon'] ) ) : ?>
                        <span class="feature-icon"><i class="<?php echo esc_attr( $atts['icon'] ); ?>"></i></span>
                    <?php endif; ?>
                    <?php if ( ! empty( $atts['title'] ) ) : ?>
                        <h3 class="feature-title"><?php echo esc_html( $atts['title'] ); ?></h3>
                    <?php endif; ?>
                    <?php echo wpautop( do_shortcode( $content ) ); ?>
                </div>
            </div>

            <?php return ob_get_clean();

        }

    }
}
?>