(function($){ "use strict";
$(document).ready(function(){

	// add your scripts here

});
})(jQuery);