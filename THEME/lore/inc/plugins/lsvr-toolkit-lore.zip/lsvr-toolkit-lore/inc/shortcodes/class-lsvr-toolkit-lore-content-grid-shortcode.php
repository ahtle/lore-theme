<?php
/**
 * Content grid
 *
 * Widgetized content area
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Content_Grid_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Content_Grid_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_content_grid', array(
                'title' => esc_html__( 'Content Grid', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'Display widgets from Content Grid sidebar (you can populate it under Appearance / Widgets). Optionally, you can choose to display widgets from one of the custom sidebars', 'lsvr-toolkit-lore' ),
                'atts' => array(
                    'title' => array(
                        'label' => esc_html__( 'Title', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Leave blank to hide title', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'columns' => array(
                        'label' => esc_html__( 'Columns', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'How many columns to display', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( '1' => 1, '2' => 2, '3' => 3, '4' => 4 ),
                        'default' => '4',
                    ),
                    'masonry' => array(
                        'label' => esc_html__( 'Enable Masonry', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Use masonry layout for grid', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( 'yes' => esc_html__( 'Yes', 'lsvr-toolkit-lore' ), 'no' => esc_html__( 'No', 'lsvr-toolkit-lore' ) ),
                        'default' => 'yes',
                    ),
                    'more_btn_label' => array(
                        'label' => esc_html__( 'More Button Label', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Leave blank to hide More button', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'more_btn_link' => array(
                        'label' => esc_html__( 'More Button Link', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

            // Add Sidebar attribute
            $custom_sidebars_count = get_theme_mod( 'custom_sidebars_count', 1 ) < 1 ? 1 : (int) get_theme_mod( 'custom_sidebars_count', 1 );
            $grid_att_values = [];
            $grid_att_values[ 'lsvr-lore-content-grid-sidebar' ] = esc_html__( 'Content Grid', 'lsvr-toolkit-lore' );
            for ( $i = 1; $i <= $custom_sidebars_count; $i++ ) {
                $grid_att_values[ 'lsvr-lore-custom-sidebar-' . $i ] = sprintf( esc_html__( 'Custom Sidebar %d', 'lsvr-toolkit-lore' ), $i );
            }
            $this->add_att(array(
                'name' => 'sidebar',
                'atts' => array(
                    'label' => esc_html__( 'Custom Sidebar', 'lsvr-toolkit-lore' ),
                    'description' => esc_html__( 'Which sidebar to be used. You can populate sidebars under Appearance / Widgets', 'lsvr-toolkit-lore' ),
                    'type' => 'select',
                    'values' => $grid_att_values,
                ),
                'add_as_first' => true,
            ));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'title' => '',
                    'sidebar' => 'lsvr-lore-content-grid-sidebar',
                    'columns' => '4',
                    'masonry' => 'yes',
                    'more_btn_label' => '',
                    'more_btn_link' => '',
                    'custom_class' => '',
                ),
                $atts
            );

            $class_arr[] = $atts['custom_class'];
            $class_arr[] = 'm-' . esc_attr( $atts['columns'] ) . '-columns';
            $class_arr[] = 'yes' === $atts['masonry'] ? 'm-masonry' : '';
            $class = implode( ' ', array_filter( $class_arr ) ) !== '' ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <div class="c-content-grid<?php echo esc_attr( $class ); ?>">
                <div class="content-grid-inner">

                    <?php if ( ( ! empty( $atts['title'] ) ) || ( ! empty( $atts['more_btn_label'] ) && ! empty(  $atts['more_btn_link'] ) ) ) : ?>
                    <div class="content-grid-header">
                        <div class="content-grid-header-inner">
                            <h5 class="content-grid-title"><?php echo esc_html( $atts['title'] ); ?></h5>
                            <?php if ( ! empty( $atts['more_btn_label'] ) && ! empty( $atts['more_btn_link'] ) ) : ?>
                                <p class="content-grid-btn"><a href="<?php echo esc_url( $atts['more_btn_link'] ); ?>" class="c-button"><?php echo esc_html( $atts['more_btn_label'] ); ?></a></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="content-grid-bricks" data-custom-sidebar="<?php echo esc_attr( $atts['sidebar'] ); ?>">
                        <?php if ( is_active_sidebar( $atts['sidebar'] ) ) : ?>

                            <?php if ( 'lsvr-lore-content-grid-sidebar' === $atts['sidebar'] ) : ?>

                                <ul class="brick-list">
                                    <?php dynamic_sidebar( $atts['sidebar'] ); ?>
                                </ul>

                            <?php else : ?>

                                <div class="brick-list">
                                    <?php dynamic_sidebar( $atts['sidebar'] ); ?>
                                </div>

                            <?php endif; ?>

                        <?php else : ?>
                            <p class="c-alert-message"><?php echo esc_html__( 'No widgets', 'lsvr-toolkit-lore' ); ?></p>
                        <?php endif; ?>

                    </div>

                    <?php if ( ! empty( $atts['more_btn_label'] ) && ! empty(  $atts['more_btn_link'] ) ) : ?>
                    <div class="content-grid-footer">
                        <div class="content-grid-footer-inner">
                            <p class="content-grid-btn"><a href="<?php echo esc_url( $atts['more_btn_link'] ); ?>" class="c-button"><?php echo esc_html( $atts['more_btn_label'] ); ?></a></p>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>
            </div>

            <?php return ob_get_clean();

        }

    }
}
?>