<?php
/**
 * Tab item
 *
 * It have to be nested in Tabs shortcode
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Tab_Item_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
	class Lsvr_Toolkit_Lore_Tab_Item_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

			parent::__construct( 'lore_tab_item', array(
				'title' => esc_html__( 'Tab Item', 'lsvr-toolkit-lore' ),
				'description' => esc_html__( 'This shortcode have to be nested in Tabs shortcode', 'lsvr-toolkit-lore' ),
                'paired' => true,
                'atts' => array(
                    'title' => array(
                        'label' => esc_html__( 'Title', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Title of this tab', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
			));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'title' => '',
                    'custom_class' => '',
                ),
                $atts
            );
            $class_arr[] = $atts['custom_class'];
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            array_push( parent::$tabs_title_arr, $atts['title'] );

            ob_start(); ?>

            <li class="tab-item<?php echo count( parent::$tabs_title_arr ) === 1 ? ' m-active' : ''; ?><?php echo esc_attr( $class ); ?>">

            <?php echo do_shortcode( wpautop( $content ) ); ?>

            </li>

            <?php return ob_get_clean();

        }

	}
}
?>