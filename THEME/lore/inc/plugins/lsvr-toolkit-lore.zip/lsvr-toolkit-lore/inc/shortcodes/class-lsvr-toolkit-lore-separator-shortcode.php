<?php
/**
 * Separator
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_Separator_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_Separator_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_separator', array(
                'title' => esc_html__( 'Separator', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'Separate content blocks', 'lsvr-toolkit-lore' ),
                'atts' => array(
                    'style' => array(
                        'label' => esc_html__( 'Style', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Style of the separator line', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( 'default' => esc_html__( 'Default', 'lsvr-toolkit-lore' ), 'transparent' => esc_html__( 'Transparent', 'lsvr-toolkit-lore' ) ),
                        'default' => 'default',
                    ),
                    'size' => array(
                        'label' => esc_html__( 'Size', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Size of top and bottom margins', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( 'small' => esc_html__( 'Small', 'lsvr-toolkit-lore' ), 'medium' => esc_html__( 'Medium', 'lsvr-toolkit-lore' ), 'large' => esc_html__( 'Large', 'lsvr-toolkit-lore' ) ),
                        'default' => 'medium',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'style' => 'default',
                    'size' => 'medium',
                    'custom_class' => '',
                ),
                $atts
            );

            $class_arr[] = $atts['custom_class'];
            $class_arr[] = 'm-style-' . esc_attr( $atts['style'] );
            $class_arr[] = 'm-size-' . esc_attr( $atts['size'] );
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            ob_start(); ?>

            <hr class="c-separator<?php echo esc_attr( $class ); ?>">

            <?php return ob_get_clean();

        }

    }
}
?>