<?php
/**
 * Knowledge base articles widget
 *
 * Display list of Knowledge Base articles
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_KB_Articles_Widget' ) ) {
class Lsvr_Toolkit_Lore_KB_Articles_Widget extends WP_Widget {

	protected $defaults;

    public function __construct() {
        $widget_ops = array(
    		'classname' => 'lsvr-kb-articles',
    		'description' => esc_html__( 'Knowledge Base Articles', 'lsvr-toolkit-lore' ),
		);
        parent::__construct( 'lsvr_lore_kb_articles_widget', esc_html__( 'Lore Knowledge Base Articles', 'lsvr-toolkit-lore' ), $widget_ops );
		$this->defaults = array(
			'title' => esc_html__( 'Knowledge Base Articles', 'lsvr-toolkit-lore' ),
			'category' => 0,
			'order' => 'default',
			'limit' => 5,
			'show_icon' => 'on',
			'show_date' => 'on',
			'show_rating' => 'on',
			'show_excerpt' => 'on',
			'show_all_btn_label' => esc_html__( 'See All Articles', 'lsvr-toolkit-lore' ),
		);
    }

    function form( $instance ) {

        $instance = wp_parse_args( (array) $instance, $this->defaults );
        $instance['category'] = (int) $instance['category'];
        $instance['limit'] = (int) $instance['limit'];

        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'lsvr-toolkit-lore' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
        </p>

		<?php $terms_arr = get_terms( 'lsvr_lore_kb_cat' ); ?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>"><?php echo esc_html__( 'Category:', 'lsvr-toolkit-lore' ); ?></label>
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'category' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'category' ) ); ?>">
			<option value="0"<?php if ( 0 === $instance['category'] ) { echo ' selected'; } ?>><?php esc_html_e( 'None', 'lsvr-toolkit-lore' ); ?></option>
			<?php if ( is_array( $terms_arr ) ) : ?>
				<?php foreach ( $terms_arr as $term ) : ?>
					<?php if ( is_object( $term ) && property_exists( $term, 'term_id' ) && property_exists( $term, 'name' ) ) : ?>
						<option value="<?php echo esc_attr( $term->term_id ); ?>"<?php if ( ( $instance['category'] > 0 ) && ( $instance['category'] === $term->term_id ) ) { echo ' selected'; } ?>><?php echo esc_attr( $term->name ); ?></option>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php endif; ?>
		</select></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'order' ) ); ?>"><?php echo esc_html__( 'Order:', 'lsvr-toolkit-lore' ); ?></label>
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'order' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'order' ) ); ?>">
			<option value="default"<?php if ( $instance['order'] === 'default' ) { echo ' selected'; } ?>><?php esc_html_e( 'Default', 'lsvr-toolkit-lore' ); ?></option>
			<option value="recent"<?php if ( $instance['order'] === 'recent' ) { echo ' selected'; } ?>><?php esc_html_e( 'Recent', 'lsvr-toolkit-lore' ); ?></option>
			<option value="popular"<?php if ( $instance['order'] === 'popular' ) { echo ' selected'; } ?>><?php esc_html_e( 'Popular', 'lsvr-toolkit-lore' ); ?></option>
		</select></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>"><?php echo esc_html__( 'Limit:', 'lsvr-toolkit-lore' ); ?></label>
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>">
			<option value="0"<?php if ( $instance['limit'] === 0 ) { echo ' selected'; } ?>><?php esc_html_e( 'None (list all)', 'lsvr-toolkit-lore' ); ?></option>
			<?php for ( $i = 1; $i <= 10; $i++ ) : ?>
				<option value="<?php echo esc_attr( $i ); ?>"<?php if ( $instance['limit'] === $i ) { echo ' selected'; } ?>><?php echo esc_attr( $i ); ?></option>
			<?php endfor; ?>
		</select></p>

		<p>
			<input class="checkbox" type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_icon' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_icon' ) ); ?>" <?php if ( 'on' === $instance['show_icon'] ) { echo ' checked'; } ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_icon' ) ); ?>"><?php echo esc_html__( 'Show Icon', 'lsvr-toolkit-lore' ); ?></label>
        </p>

		<p>
			<input class="checkbox" type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_date' ) ); ?>" <?php if ( 'on' === $instance['show_date'] ) { echo ' checked'; } ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>"><?php echo esc_html__( 'Show Date', 'lsvr-toolkit-lore' ); ?></label>
        </p>

		<p>
			<input class="checkbox" type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_rating' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_rating' ) ); ?>" <?php if ( 'on' === $instance['show_rating'] ) { echo ' checked'; } ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_rating' ) ); ?>"><?php echo esc_html__( 'Show Rating', 'lsvr-toolkit-lore' ); ?></label>
        </p>

		<p>
			<input class="checkbox" type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_excerpt' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_excerpt' ) ); ?>" <?php if ( 'on' === $instance['show_excerpt'] ) { echo ' checked'; } ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_excerpt' ) ); ?>"><?php echo esc_html__( 'Show Excerpt', 'lsvr-toolkit-lore' ); ?></label>
        </p>

		<p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_all_btn_label' ) ); ?>"><?php echo esc_html__( 'More Button Label:', 'lsvr-toolkit-lore' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'show_all_btn_label' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_all_btn_label' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['show_all_btn_label'] ); ?>" >
        </p>
		<p><?php esc_html_e( 'Leave blank do disable more button.', 'lsvr-toolkit-lore' ); ?></p>

        <?php

    }

    function update( $new_instance, $old_instance ) {

        $instance = $old_instance;

        $instance['title'] = $new_instance['title'];
		$instance['category'] = $new_instance['category'];
		$instance['order'] = $new_instance['order'];
		$instance['limit'] = $new_instance['limit'];
		$instance['show_icon'] = $new_instance['show_icon'];
		$instance['show_date'] = $new_instance['show_date'];
		$instance['show_rating'] = $new_instance['show_rating'];
		$instance['show_excerpt'] = $new_instance['show_excerpt'];
		$instance['show_all_btn_label'] = $new_instance['show_all_btn_label'];
        return $instance;

    }

    function widget( $args, $instance ) {

        $instance = wp_parse_args( (array) $instance, $this->defaults );
        $instance['title'] = apply_filters( 'widget_title', $instance['title'] );
		$instance['category'] = (int) $instance['category'];
        $instance['limit'] = 0 === (int) $instance['limit'] ? 1000 : (int) $instance['limit'];
        $instance['show_icon'] = 'on' === $instance['show_icon'] ? true : false;
        $instance['show_date'] = 'on' === $instance['show_date'] ? true : false;
        $instance['show_rating'] = 'on' === $instance['show_rating'] ? true : false;
        $instance['show_excerpt'] = 'on' === $instance['show_excerpt'] ? true : false;

        // Add custom classes
        $classes = array();
        $classes[] = true === $instance['show_icon'] ? 'm-has-icon' : null;
        $classes[] = true === $instance['show_date'] ? 'm-has-date' : null;
        $classes[] = true === $instance['show_rating'] ? 'm-has-rating' : null;
        $classes[] = true === $instance['show_excerpt'] ? 'm-has-excerpt' : null;
        $classes = array_filter( $classes );
        if ( ! empty( $classes ) ) {
			$args['before_widget'] = str_replace( 'class="', 'class="' . implode( ' ', $classes ) . ' ' , $args['before_widget'] );
		}
        ?>

		<?php echo $args['before_widget']; ?>
        <?php if ( '' !== $instance['title'] ) { echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title']; } ?>
        <div class="widget-content">

			<?php // Override any 3rd party filters for this query if order is set to Recent
			if ( 'recent' === $instance['order'] ) {
				add_filter( 'pre_get_posts', 'lsvr_toolkit_lore_kb_articles_widget_recent_order', 99 );
				if ( ! function_exists( 'lsvr_toolkit_lore_kb_articles_widget_recent_order' ) ) {
					function lsvr_toolkit_lore_kb_articles_widget_recent_order( $query ) {

						$query->set( 'order', 'DESC' );
						$query->set( 'orderby', 'date' );

	    				remove_filter( current_filter(), __FUNCTION__, 99 );
	    				return $query;

					}
				}
			}

			// Override any 3rd party filters for this query if order is set to Popular
			elseif ( 'popular' === $instance['order'] ) {
				add_filter( 'pre_get_posts', 'lsvr_toolkit_lore_kb_articles_widget_popular_order', 99 );
				if ( ! function_exists( 'lsvr_toolkit_lore_kb_articles_widget_popular_order' ) ) {
					function lsvr_toolkit_lore_kb_articles_widget_popular_order( $query ) {

						// Get rating type
						$rating_type = true == get_theme_mod( 'kb_rating_dislikes_enable', true ) ? get_theme_mod( 'kb_rating_type', 'difference' ) : 'likes_only';

						$query->set( 'order', 'DESC' );
						$query->set( 'orderby', 'meta_value_num' );

						// Sort by difference
						if ( 'both' === $rating_type || 'difference' === $rating_type ) {
							$query->set( 'meta_key', 'lsvr_lore_rating_diff' );
						}

						// Sort by likes
						else {

							$query->set( 'meta_key', 'lsvr_lore_likes_count' );
						}

						remove_filter( current_filter(), __FUNCTION__, 99 );
						return $query;

					}
				}
			}

			// If order is set to default, order by Customizer settings
			else {

				if ( 'date_desc' === get_theme_mod( 'kb_articles_order', 'default' ) ) {
					$query_order['order'] = 'DESC';
					$query_order['orderby'] = 'date';
				} elseif ( 'date_asc' === get_theme_mod( 'kb_articles_order', 'default' ) ) {
					$query_order['order'] = 'ASC';
					$query_order['orderby'] = 'date';
				} elseif ( 'title' === get_theme_mod( 'kb_articles_order', 'default' ) ) {
					$query_order['order'] = 'ASC';
					$query_order['orderby'] = 'title';
				}

			}

			// Query args
			$query_args = array(
				'posts_per_page' => (int) $instance['limit'],
				'post_type' => 'lsvr_lore_kb',
				'post_status' => array( 'publish' ),
				'suppress_filters' => true,
			);
			if ( ! empty( $query_order ) ) {
				$query_args = array_merge( $query_args, $query_order );
			}

			// Query category
			if ( $instance['category'] > 0 ) {
				$query_args['tax_query'] = array(
					array(
						'taxonomy' => 'lsvr_lore_kb_cat',
						'field' => 'id',
						'terms' => array( (int) $instance['category'] )
					)
				);
			}

			// First query call
			$posts = get_posts( $query_args );
			/**
			 * Second query call
			 *
			 * If the first query call returns blank array it means they are either no articles, or none of the articles have been rated yet (if order is set to Popular)
			 * in that case, attempt to do the query again, this second query will be called without meta key order as the filter gets automatically removed after its first use
			 */
			$posts = empty( $posts ) ? get_posts( $query_args ) : $posts;
			?>

			<?php // Get ID of current KB article (if any)
			if ( is_singular( 'lsvr_lore_kb' ) ) {
				global $wp_query;
				$current_id = $wp_query->queried_object;
				$current_id = $current_id->ID;
			} else {
				$current_id = false;
			} ?>

			<?php // Loop
			if ( ! empty( $posts ) ) : ?>

				<ul>
				<?php foreach ( $posts as $post ) : ?>

					<?php $post_item_class = [];
					$post_item_class[] = ! empty( $instance['show_icon'] ) ? 'm-has-icon' : '';
					$post_item_class[] = ! empty( $instance['show_rating'] ) ? 'm-has-rating' : '';
					$kb_rating_dislikes_enable = get_theme_mod( 'kb_rating_dislikes_enable', true );
					$post_item_class[] = ! empty( $kb_rating_dislikes_enable ) && 'both' === get_theme_mod( 'kb_rating_type', 'difference' ) ? 'm-has-rating-both' : '';
					$post_item_class = array_filter( $post_item_class );
					$post_item_class = ! empty( $post_item_class ) ?  ' ' . implode( ' ', $post_item_class ) : ''; ?>

					<li class="post-item<?php if ( $current_id === $post->ID ) { echo ' m-current'; } ?><?php echo esc_attr( $post_item_class ); ?>">

						<?php if ( ! empty( $instance['show_date'] ) ) : ?>
							<div class="post-date"><?php echo esc_html( get_the_date( get_option( 'date_format' ), $post->ID ) ); ?></div>
						<?php endif; ?>

						<div class="post-title-holder">

							<?php if ( ! empty( $instance['show_icon'] ) ) : ?>
							<?php if ( function_exists( 'lsvr_lore_the_kb_post_icon' ) ) {
                                lsvr_lore_the_kb_post_icon( $post->ID, 'post-icon' );
                            } ?>
							<?php endif; ?>

							<a href="<?php echo esc_url( get_post_permalink( $post->ID ) ); ?>" class="post-title"><?php echo esc_html( $post->post_title ); ?></a>

							<?php if ( ! empty( $instance['show_rating'] ) && function_exists( 'lsvr_lore_the_post_rating_values' ) ) : ?>
								<?php lsvr_lore_the_post_rating_values( $post->ID ); ?>
							<?php endif; ?>

						</div>

						<?php if ( ! empty( $instance['show_excerpt'] ) ) : ?>
							<div class="post-excerpt">

								<?php if ( ! empty( $post->post_excerpt ) ) {
									echo wpautop( $post->post_excerpt );
								} elseif ( strpos( $post->post_content, '<!--more-->' ) ) {
									$post_excerpt = get_extended( $post->post_content );
									echo ! empty( $post_excerpt['main'] ) ? $post_excerpt['main'] : '';
								} ?>

							</div>
						<?php endif; ?>

					</li>

				<?php endforeach; ?>
				</ul>

				<?php if ( '' !== $instance['show_all_btn_label'] ) : ?>
					<?php $show_all_btn_link = $instance['category'] > 0 ? get_term_link( (int) $instance['category'], 'lsvr_lore_kb_cat' ) : get_post_type_archive_link( 'lsvr_lore_kb' ); ?>
					<p class="widget-more-link">
						<a href="<?php echo esc_url( $show_all_btn_link ); ?>"><?php echo esc_html( $instance['show_all_btn_label'] ); ?></a>
					</p>
				<?php endif; ?>

			<?php else : ?>

				<p><?php esc_html_e( 'There are no Knowledge Base articles at this time', 'lsvr-toolkit-lore' ); ?></p>

			<?php endif; ?>

        </div>
		<?php echo $args['after_widget']; ?>

        <?php

    }

}}

?>