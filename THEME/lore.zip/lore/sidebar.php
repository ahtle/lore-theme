<?php if ( is_active_sidebar( 'lsvr-lore-default-sidebar' ) ) : ?>
<!-- SIDEBAR : begin -->
<aside id="sidebar" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
	<div class="sidebar-inner">

		<?php dynamic_sidebar( 'lsvr-lore-default-sidebar' ); ?>

	</div>
</aside>
<!-- SIDEBAR : end -->
<?php endif; ?>