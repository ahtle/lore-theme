<?php
/**
 * Knowledge Base articles
 *
 * Lists Knowledge Base posts
 */
if ( ! class_exists( 'Lsvr_Toolkit_Lore_KB_Articles_Shortcode' ) && class_exists( 'Lsvr_Toolkit_Lore_Shortcode' ) ) {
    class Lsvr_Toolkit_Lore_KB_Articles_Shortcode extends Lsvr_Toolkit_Lore_Shortcode {

        public function __construct() {

            parent::__construct( 'lore_kb_articles', array(
                'title' => esc_html__( 'Knowledge Base Articles', 'lsvr-toolkit-lore' ),
                'description' => esc_html__( 'List Knowledge Base articles. You can manage them under Knowledge Base section of admin', 'lsvr-toolkit-lore' ),
                'atts' => array(
                    'title' => array(
                        'label' => esc_html__( 'Title', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                        'default' => esc_html__( 'Knowledge Base', 'lsvr-toolkit-lore' ),
                    ),
                    'order' => array(
                        'label' => esc_html__( 'Article Order', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( 'default' => esc_html__( 'Default', 'lsvr-toolkit-lore' ), 'recent' => esc_html__( 'Recent', 'lsvr-toolkit-lore' ), 'popular' => esc_html__( 'Popular', 'lsvr-toolkit-lore' ) ),
                        'default' => 'default',
                    ),
                    'limit' => array(
                        'label' => esc_html__( 'Number of Articles', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array( '0' => esc_html__( 'All', 'lsvr-toolkit-lore' ), '1' => 1, '2' => 2, '3' => 3, '4' => 4, '5' => 5, '6' => 6, '7' => 7, '8' => 8, '9' => 9, '10' => 10 ),
                        'default' => '0',
                    ),
                    'show_icon' => array(
                        'label' => esc_html__( 'Show Article Icon', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array(
                            'yes' => esc_html__( 'Enable', 'lsvr-toolkit-lore' ),
                            'no' => esc_html__( 'Disable', 'lsvr-toolkit-lore' ),
                        ),
                        'default' => 'yes',
                    ),
                    'show_date' => array(
                        'label' => esc_html__( 'Show Publish Date', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array(
                            'yes' => esc_html__( 'Enable', 'lsvr-toolkit-lore' ),
                            'no' => esc_html__( 'Disable', 'lsvr-toolkit-lore' ),
                        ),
                        'default' => 'yes',
                    ),
                    'show_rating' => array(
                        'label' => esc_html__( 'Show Rating', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array(
                            'yes' => esc_html__( 'Enable', 'lsvr-toolkit-lore' ),
                            'no' => esc_html__( 'Disable', 'lsvr-toolkit-lore' ),
                        ),
                        'default' => 'yes',
                    ),
                    'show_excerpt' => array(
                        'label' => esc_html__( 'Show Excerpt', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => array(
                            'yes' => esc_html__( 'Enable', 'lsvr-toolkit-lore' ),
                            'no' => esc_html__( 'Disable', 'lsvr-toolkit-lore' ),
                        ),
                        'default' => 'yes',
                    ),
                    'more_btn_label' => array(
                        'label' => esc_html__( 'More Button Label', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Link to Knowledge Base archive. Leave blank to hide More button', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                    'custom_class' => array(
                        'label' => esc_html__( 'Custom Class', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'It can be used for applying custom CSS', 'lsvr-toolkit-lore' ),
                        'type' => 'text',
                    ),
                ),
            ));

            // Add categories
            $categories_tax = get_categories( 'taxonomy=lsvr_lore_kb_cat&hide_empty=1&hierarchical=0&parent=0' ) ;
            if ( count( $categories_tax ) > 0 ) {
                $values = array( '0' => esc_html__( 'None', 'lsvr-toolkit-lore' ) );
                foreach ( $categories_tax as $value ) {
                    $values[ $value->cat_ID ] = $value->name;
                }
                $this->add_att(array(
                    'name' => 'category',
                    'atts' => array(
                        'label' => esc_html__( 'Category', 'lsvr-toolkit-lore' ),
                        'description' => esc_html__( 'Category to load Knowledge Base articles from. Choose "None" to load articles regardless of category', 'lsvr-toolkit-lore' ),
                        'type' => 'select',
                        'values' => $values,
                        'default' => '0',
                    ),
                    'add_as_first' => true,
                ));
            }

        }

        // Generate the output
        public static function shortcode( $atts, $content = '' ) {

            // Merge default atts and received atts
            $atts = shortcode_atts(
                array(
                    'category' => '0',
                    'title' => '',
                    'order' => 'default',
                    'limit' => '0',
                    'show_icon' => 'yes',
                    'show_date' => 'yes',
                    'show_rating' => 'yes',
                    'show_excerpt' => 'yes',
                    'more_btn_label' => '',
                    'custom_class' => '',
                ),
                $atts
            );

            $atts['category'] = (int) $atts['category'];
            $atts['limit'] = (int) $atts['limit'] < 1 ? 1000 : (int) $atts['limit'];
            $atts['show_icon'] = 'yes' === esc_attr( $atts['show_icon'] ) ? true : false;
            $atts['show_date'] = 'yes' === esc_attr( $atts['show_date'] ) ? true : false;
            $atts['show_rating'] = 'yes' === esc_attr( $atts['show_rating'] ) ? true : false;
            $atts['show_excerpt'] = 'yes' === esc_attr( $atts['show_excerpt'] ) ? true : false;

            $class_arr[] = true === $atts['show_icon'] ? 'm-has-icons' : '';
            $class_arr[] = $atts['custom_class'];
            $class = '' !== implode( ' ', array_filter( $class_arr ) ) ? ' ' . implode( ' ', array_filter( $class_arr ) ) : '';

            // Override any 3rd party filters for this query if order is set to Recent
            if ( 'recent' === $atts['order'] ) {
                add_filter( 'pre_get_posts', 'lsvr_toolkit_lore_kb_articles_shortcode_recent_order', 99 );
                if ( ! function_exists( 'lsvr_toolkit_lore_kb_articles_shortcode_recent_order' ) ) {
                    function lsvr_toolkit_lore_kb_articles_shortcode_recent_order( $query ) {

                        $query->set( 'order', 'DESC' );
                        $query->set( 'orderby', 'date' );

                        remove_filter( current_filter(), __FUNCTION__, 99 );
                        return $query;

                    }
                }
            }

            // Override any 3rd party filters for this query if order is set to Popular
            elseif ( 'popular' === $atts['order'] ) {
                add_filter( 'pre_get_posts', 'lsvr_toolkit_lore_kb_articles_shortcode_popular_order', 99 );
                if ( ! function_exists( 'lsvr_toolkit_lore_kb_articles_shortcode_popular_order' ) ) {
                    function lsvr_toolkit_lore_kb_articles_shortcode_popular_order( $query ) {

                        // Get rating type
                        $rating_type = true == get_theme_mod( 'kb_rating_dislikes_enable', true ) ? get_theme_mod( 'kb_rating_type', 'difference' ) : 'likes_only';

                        $query->set( 'order', 'DESC' );
                        $query->set( 'orderby', 'meta_value_num' );

                        // Sort by difference
                        if ( 'both' === $rating_type || 'difference' === $rating_type ) {
                            $query->set( 'meta_key', 'lsvr_lore_rating_diff' );
                        }

                        // Sort by likes
                        else {
                            $query->set( 'meta_key', 'lsvr_lore_likes_count' );
                        }

                        remove_filter( current_filter(), __FUNCTION__, 99 );
                        return $query;

                    }
                }
            }

            // If order is set to default, order by Customizer settings
            else {

                if ( 'date_desc' === get_theme_mod( 'kb_articles_order', 'default' ) ) {
                    $query_order['order'] = 'DESC';
                    $query_order['orderby'] = 'date';
                } elseif ( 'date_asc' === get_theme_mod( 'kb_articles_order', 'default' ) ) {
                    $query_order['order'] = 'ASC';
                    $query_order['orderby'] = 'date';
                } elseif ( 'title' === get_theme_mod( 'kb_articles_order', 'default' ) ) {
                    $query_order['order'] = 'ASC';
                    $query_order['orderby'] = 'title';
                }

            }

            // Query args
            $query_args = array(
                'posts_per_page' => (int) $atts['limit'],
                'post_type' => 'lsvr_lore_kb',
                'post_status' => array( 'publish' ),
                'suppress_filters' => true,
            );
            if ( ! empty( $query_order ) ) {
                $query_args = array_merge( $query_args, $query_order );
            }

            // Query category
            if ( $atts['category'] > 0 ) {
                $query_args['tax_query'] = array(
                    array(
                        'taxonomy' => 'lsvr_lore_kb_cat',
                        'field' => 'id',
                        'terms' => array( (int) $atts['category'] )
                    )
                );
            }

            // First query call
            $posts = get_posts( $query_args );
            /**
             * Second query call
             *
             * If the first query call returns blank array it means they are either no articles, or none of the articles have been rated yet (if order is set to Popular)
             * in that case, attempt to do the query again, this second query will be called without meta key order as the filter gets automatically removed after its first use
             */
            $posts = empty( $posts ) ? get_posts( $query_args ) : $posts;

            // Get ID of current KB article (if any)
            if ( is_singular( 'lsvr_lore_kb' ) ) {
                global $wp_query;
                $current_id = $wp_query->queried_object;
                $current_id = $current_id->ID;
            } else {
                $current_id = false;
            }

            ob_start(); ?>

            <div class="c-kb-articles<?php echo esc_attr( $class ); ?>">
                <div class="kb-articles-inner">

                    <?php if ( '' !== $atts['title'] ) : ?>
                    <h2><span><?php echo esc_html( $atts['title'] ); ?></span></h2>
                    <?php endif; ?>

                    <?php if ( ! empty( $posts ) ) : ?>

                        <div class="kb-articles-list">
                        <?php foreach ( $posts as $post ) : ?>
                            <article class="kb-article-item<?php if ( function_exists( 'lsvr_lore_has_post_rating_values' ) && lsvr_lore_has_post_rating_values( $post->ID ) ) { echo ' m-has-post-rating'; } ?>">
                                <div class="kb-article-item-inner">

                                    <!-- POST HEADER : begin -->
                                    <header class="kb-article-header">
                                        <?php if ( true === $atts['show_icon'] && function_exists( 'lsvr_lore_the_kb_post_icon' ) ) : ?>
                                            <?php lsvr_lore_the_kb_post_icon( $post->ID, 'kb-article-icon' ); ?>
                                        <?php endif; ?>
                                        <h3 class="kb-article-title" itemprop="headline">
                                            <a href="<?php echo esc_url( get_permalink( $post->ID ) ); ?>" rel="bookmark"><?php echo get_the_title( $post->ID ); ?></a>
                                        </h3>
                                    </header>
                                    <!-- POST HEADER : end -->

                                    <?php if ( true === $atts['show_excerpt'] && ! empty( $post->post_excerpt ) ) : ?>
                                    <!-- POST CONTENT : begin -->
                                    <div class="kb-article-content" itemprop="text">
                                        <?php echo wpautop( $post->post_excerpt ); ?>
                                    </div>
                                    <!-- POST CONTENT : end -->
                                    <?php endif; ?>

                                    <!-- POST FOOTER : begin -->
                                    <div class="kb-article-footer">

                                        <?php if ( true === $atts['show_date'] ) : ?>
                                            <div class="kb-article-date"><?php echo get_the_date( get_option( 'date_format' ), $post->ID ); ?></div>
                                        <?php endif; ?>

                                        <?php if ( true === $atts['show_rating'] && function_exists( 'lsvr_lore_the_post_rating_values' ) ) {
                                            lsvr_lore_the_post_rating_values( $post->ID );
                                        } ?>
                                    </div>
                                    <!-- POST CONTENT : end -->

                                </div>
                            </article>
                        <?php endforeach; ?>
                        </div>

                        <?php if ( '' !== $atts['more_btn_label'] ) : ?>
                            <?php $more_btn_link = $atts['category'] > 0 ? get_term_link( (int) $atts['category'], 'lsvr_lore_kb_cat' ) : get_post_type_archive_link( 'lsvr_lore_kb' ); ?>
                            <p class="c-more-link"><a href="<?php echo esc_url( $more_btn_link ); ?>"><?php echo esc_html( $atts['more_btn_label'] ); ?></a></p>
                        <?php endif; ?>

                    <?php else : ?>
                        <?php echo wpautop( esc_html__( 'There are no Knowledge Base articles at this time', 'lsvr-toolkit-lore' ) ); ?>
                    <?php endif; ?>

                </div>
            </div>

            <?php return ob_get_clean();

        }

    }
}
?>